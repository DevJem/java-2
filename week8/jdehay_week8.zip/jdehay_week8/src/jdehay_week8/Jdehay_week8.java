package jdehay_week8;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week8
 * @Date: Mar 25, 2018
 * @Description: this program reads a comma separated value file into a map
 *          and performs CRUD operations on it through a gui.
 * @Note: This program was written on a Linux build
 */
//Imports
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

//Begin Class Jdehay_week8
public class Jdehay_week8 extends Application {

    private static TextField tfName = new TextField();
    private static TextField tfAge = new TextField();
    private static TextArea taPath = new TextArea();
    private static TextArea taResult = new TextArea();
    private static Button btnOpen = new Button("Open File");
    private static Button btnRead = new Button("Read File");
    private static Button btnEnter = new Button("Enter");
    private static Button btnRemove = new Button("Remove");
    private static Button btnClear = new Button("Clear");
    private static Button btnExit = new Button("Exit");
    private static Map<String, Integer> map = new TreeMap<>();
    private static File path;

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(500);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Mapping Data");
        Text topText2 = new Text("Load and Modify a data file!");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox(5);
        middle.setPadding(new Insets(5));

        // Wrap textareas and prevent editing
        taPath.setWrapText(true);
        taPath.setEditable(false);
        taResult.setWrapText(true);
        taResult.setEditable(false);

        /**
         * Left
         */
        int iLblWidth = 100;    // width of labels

        // container for left side
        VBox left = new VBox(10);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.CENTER);
        left.setPrefWidth(550);

        // name entry
        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label lblTop = new Label("Name: ");
        lblTop.setPrefWidth(iLblWidth);
        tfName.requestFocus();
        leftTop.getChildren().addAll(lblTop, tfName);

        // age entry
        HBox leftMid = new HBox();
        leftMid.setAlignment(Pos.CENTER_LEFT);
        Label lblMid = new Label("Age: ");
        lblMid.setPrefWidth(iLblWidth);
        leftMid.getChildren().addAll(lblMid, tfAge);

        // add labels and textfields to left
        left.getChildren().addAll(leftTop, leftMid);

        // add path to left
        HBox pathLbl = new HBox();
        Label lblPath = new Label("File Path:");
        pathLbl.getChildren().add(lblPath);

        left.getChildren().addAll(pathLbl, taPath);

        // add left to middle
        middle.getChildren().add(left);

        /**
         * Right
         */
        taResult.setStyle("-fx-border-color: red;");
        middle.getChildren().add(taResult);

        // add middle to container
        container.getChildren().add(middle);

        /**
         * Bottom
         */
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(40);

        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        // make buttons do stuff
        btnOpen.setOnAction(new OpenHandler(primaryStage));
        btnRead.setOnAction(new ReadHandler());
        btnEnter.setOnAction(new EnterHandler());
        btnRemove.setOnAction(new RemoveHandler());
        btnClear.setOnAction(new ClearHandler());

        bottom.getChildren().addAll(btnOpen, btnRead, btnEnter, btnRemove,
                btnClear, btnExit);
        container.getChildren().add(bottom);

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Maps");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    private static void MyAlert(String body) {

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Something is afoot...");
        alert.setContentText(body);
        alert.showAndWait();

    }  // End Alert Method

    /**
     * LoadMap method modified from the one in the assignment. It takes the data
     * in the file and places it into the map and displays it on the results
     * textarea.
     *
     * @param filepath
     * @throws FileNotFoundException
     * @throws IOException
     */
    private static void LoadMap(String filepath) throws FileNotFoundException, IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(new File(filepath)))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(",")) {
                    String[] strings = line.split(",");
                    map.put(strings[0], Integer.parseInt(strings[1]));
                }
            }
            map.entrySet().stream().forEach((entry) -> {
                String key = entry.getKey();
                int value = entry.getValue();
                taResult.appendText(key + " is " + value + " years old\n");
            });
        }
    }

    /**
     * method to rewrite the file with the information in the tree map
     * @param path 
     */
    private static void ReWriteFile(File path) {
        // code to add updated map to file from week 8 lecture
        Iterator<Map.Entry<String, Integer>> iter = map.entrySet().iterator();
        Map.Entry<String, Integer> entryPre = null;
        while (iter.hasNext()) {
            entryPre = iter.next();
        }
        /* Next, clear data file and rewrite with new map values */
        try (FileWriter fileWriter = new FileWriter(path); BufferedWriter 
                writer = new BufferedWriter(fileWriter)) {
            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                //Enter key and value separated by comma
                writer.write(entry.getKey() + "," + entry.getValue());
                /* If entry != last entry, print a newLine() */
                if (!entry.equals(entryPre)) {
                    writer.newLine();
                }
                /* Flush the buffer and write all changes */
                writer.flush();
            }
        } catch (IOException ex) {
            Logger.getLogger(Jdehay_week8.class.getName()).log(Level.SEVERE, null, ex);
        }
    }  // end ReWriteFile

    /**
     * This handles the open file button. I use a constructor on this class to
     * access the primary stage.
     */
    private static class OpenHandler implements EventHandler<ActionEvent> {

        private Stage primaryStage;

        // constructor
        private OpenHandler(Stage stage) {
            primaryStage = stage;
        }

        @Override
        public void handle(ActionEvent event) {
            FileChooser file = new FileChooser();
            file.setTitle("Open CVS File");
            path = file.showOpenDialog(primaryStage);
            try {
                taPath.setText(String.valueOf(path));
            } catch (NullPointerException e) {
                Jdehay_week8.MyAlert("File not found!");
                taPath.clear();
            }

            // I'm using this if statement here because when cancel is clicked
            // I am not getting a nullpointerexception and I am checking the
            // contents of taPath before the other buttons do anything
            if (taPath.getText().equals("null")) {
                taPath.clear();
            }
        }
    }  // end open handler

    /**
     * Locates the data file by using the file path from the File Path TextArea
     * Reads the contents of the data file Stuffs the data into a Map Displays
     * them in the Results TextArea in ascending order 
     */
    private static class ReadHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            if (taPath.getText().isEmpty()) {
                Jdehay_week8.MyAlert("Nothing to Read!");
                return;
            }
            try {
                taResult.clear();
                Jdehay_week8.LoadMap(path.toString());
            } catch (IOException ex) {
                Logger.getLogger(Jdehay_week8.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    } // end read handler

    /**
     * Handles the enter button to enter the name and age into both the map and
     * the file. Code sourced from week 8 lecture
     */
    private static class EnterHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            // validations
            if (taPath.getText().isEmpty()) {
                Jdehay_week8.MyAlert("No File Opened Yet!");
                return;
            }
            if (tfName.getText().isEmpty() || tfAge.getText().isEmpty()) {
                Jdehay_week8.MyAlert("You must enter a name AND age.");
                return;
            }
            if (!tfName.getCharacters().toString().matches("^\\D+$")) {
                MyAlert("Enter only letters for the Name\n");
                tfName.requestFocus();
                return;
            }
            if (!tfAge.getCharacters().toString().matches("^\\d+$")) {
                MyAlert("Enter only numbers for Age\n");
                tfAge.requestFocus();
                return;
            }

            // add to map and rewrite file
            map.put(tfName.getText(), Integer.parseInt(tfAge.getText()));
            ReWriteFile(path);

            // code to refresh the text area with the new information
            try {
                taResult.clear();
                Jdehay_week8.LoadMap(path.toString());
            } catch (IOException ex) {
                Logger.getLogger(Jdehay_week8.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }  // end enter handler

    /**
     * Handles the Remove button. Pops up a text input dialog to allow the user
     * to select a key to remove from the map. If it exists, it gets removed. If
     * it doesn't exist, pop up an alert. Parts of this code were sourced from
     * week 8 lecture.
     */
    private static class RemoveHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            if (taPath.getText().isEmpty()) {
                Jdehay_week8.MyAlert("Nothing to Remove!");
                return;
            }

            // Open dialog
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Remove Entry");
            dialog.setHeaderText("Remove an Entry?");
            dialog.setContentText("Please enter a key value: ");
            Optional<String> result = dialog.showAndWait();

            // chech user entry and rewrite the map and file if it matches
            if (map.containsKey(result.get())) {
                map.remove(result.get());
                ReWriteFile(path);
                try {
                    LoadMap(path.toString());
                } catch (IOException ex) {
                    Logger.getLogger(Jdehay_week8.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                MyAlert("Key not found!");
                return;
            }
            
            // code to refresh the text area with the new information
            try {
                taResult.clear();
                Jdehay_week8.LoadMap(path.toString());
            } catch (IOException ex) {
                Logger.getLogger(Jdehay_week8.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }  // end remove handler

    /**
     * clears all textfields, textareas, and the Map. Also requests focus to the
     * open file button.
     */
    private static class ClearHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            if (taPath.getText().isEmpty()) {
                Jdehay_week8.MyAlert("Nothing to Clear!");
                return;
            }

            taPath.clear();
            taResult.clear();
            tfName.clear();
            tfAge.clear();
            map.clear();
            btnOpen.requestFocus();
        }
    }  // end clear handler
}  //End Class Jdehay_week8

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
