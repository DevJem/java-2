package jdehay_week2;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week2
  *  @Date: Feb 6, 2018
  *  @Subclass CirclePane Description: creates and manipulates a circle object
  *             to be displayed in the center of the main borderpane.
  */
//Imports
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

//Begin Subclass CirclePane
class CirclePane extends StackPane {
    Circle circle = new Circle();
    
    public CirclePane() {
        /**
         * Create circle
         */
        getChildren().add(circle);
        circle.setRadius(50);
        circle.setStroke(Color.BLACK);
        circle.setFill(Color.GREEN);
        circle.setVisible(false);
    }
    
    /**
     * enlarges the square if it is visible
     */
    protected void enlarge() {
        if (circle.isVisible()) {
            circle.setRadius(circle.getRadius() * 1.1);
        }
    }
    
    /**
     * shrinks the square if it is visible
     */
    protected void shrink() {
        if (circle.isVisible()) {
            circle.setRadius(circle.getRadius() * .9);
        }
    }
    
    /**
     * changes fill color to a random color
     */
    protected void color() {
        if (circle.isVisible()) {
            circle.setFill(Color.color(Math.random(), Math.random(), Math.random()));
        }
    }

    /**
     * controls visibility as a method of ensuring what happens to the square
     * doesn't happen to the circle
     * @param b 
     */
    protected void visibility(boolean b) {
        circle.setVisible(b);
    }

} // End Subclass CirclePane

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/