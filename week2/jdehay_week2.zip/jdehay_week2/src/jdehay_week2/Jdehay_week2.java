package jdehay_week2;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: jdehay_week2
 *  @Date: Jan 29, 2018
 *  @Description: This program is an exercise in creating panes, shapes, 
 *          buttons, and action event handlers. Furthermore, it incorporates
 *          subclasses for the shapes.
 *  @Note: This program was written on a Linux build
 */

//Imports
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

//Begin Class Jdehay_week2
public class Jdehay_week2 extends Application {
//    Circle circle = new Circle();
//    Rectangle square = new Rectangle();
    private CirclePane circlePane = new CirclePane();
    private SquarePane squarePane = new SquarePane();
    private BorderPane container = new BorderPane();
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        /**
         * Container for app
         */
        container.setPrefHeight(600);
        container.setPrefWidth(600);
        container.setPadding(new Insets(10));

        /**
         * Bottom part
         */
        // create buttons
        HBox bottom = new HBox(15);
        Button enlarge = new Button("Enlarge");
        Button shrink = new Button("Shrink");
        Button addSquare = new Button("Add Square");
        Button addCircle = new Button("Add Circle");
        Button changeColor = new Button("Change Color");
        Button exit = new Button("Exit");
        bottom.getChildren().addAll(enlarge, shrink, addSquare, addCircle,
                changeColor, exit);
        bottom.alignmentProperty().set(Pos.CENTER);
        bottom.setPadding(new Insets(10));
        bottom.setStyle("-fx-border-color: red;");
        
        // do all the things
        enlarge.setOnAction(new enlargeHandler());
        shrink.setOnAction(new shrinkHandler());
        addSquare.setOnAction(new squareHandler());
        addCircle.setOnAction(new circleHandler());
        changeColor.setOnAction(new colorHandler());
        exit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });
        
        /**
         * 
         * Place everything together and show it
         * 
         */ 
        container.setBottom(bottom);

        Scene scene = new Scene(container);
        
        primaryStage.setTitle("Week 2 Assignment");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }  // End start method

    /**
     * Handles button press on enlarge
     */
    private class enlargeHandler implements EventHandler<ActionEvent> {

        public enlargeHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            squarePane.enlarge();
            circlePane.enlarge();
        }
    }

    /**
     * Handles button press on shrink
     */
    private class shrinkHandler implements EventHandler<ActionEvent> {

        public shrinkHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            squarePane.shrink();
            circlePane.shrink();
        }
    }

    /**
     * Handles button press on add square
     */
    private class squareHandler implements EventHandler<ActionEvent> {

        public squareHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            circlePane.visibility(false);
            squarePane.visibility(true);
            container.setCenter(squarePane);
        }
    }

    /**
     * Handles button press on add circle
     */
    private class circleHandler implements EventHandler<ActionEvent> {

        public circleHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            squarePane.visibility(false);
            circlePane.visibility(true);
            container.setCenter(circlePane);
        }
    }

    /**
     * Handles button press on change color
     */
    private class colorHandler implements EventHandler<ActionEvent> {

        public colorHandler() {
        }

        // https://stackoverflow.com/a/35715848/4196281
        @Override
        public void handle(ActionEvent event) {
            circlePane.color();
            squarePane.color();
        }
    }
}  //End Class Jdehay_week2

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */