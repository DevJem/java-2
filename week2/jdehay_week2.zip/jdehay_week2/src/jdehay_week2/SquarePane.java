package jdehay_week2;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week2
  *  @Date: Feb 6, 2018
  *  @Subclass SquarePane Description: creates and manipulates a square object
  *             to be displayed in the center of the main borderpane.
  */
//Imports
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

//Begin Subclass SquarePane
class SquarePane extends StackPane {
    Rectangle square = new Rectangle();
    
    public SquarePane() {
        /**
         * create square
         */
        getChildren().add(square);
        square.setHeight(100);
        square.setWidth(100);
        square.setStroke(Color.BLACK);
        square.setFill(Color.GREEN);
        square.setVisible(false);
    }
    
    /**
     * enlarges the square if it is visible
     */
    protected void enlarge() {
        if (square.isVisible()) {
            square.setWidth(square.getWidth() * 1.1);
            square.setHeight(square.getHeight() * 1.1);
        }
    }
    
    /**
     * shrinks the square if it is visible
     */
    protected void shrink() {
        if (square.isVisible()) {
            square.setWidth(square.getWidth() * .9);
            square.setHeight(square.getHeight() * .9);
        }
    }
    
    /**
     * changes fill color to a random color
     */
    protected void color() {
        if (square.isVisible()) {
            square.setFill(Color.color(Math.random(), Math.random(), Math.random()));
        }
    }

    /**
     * controls visibility as a method of ensuring what happens to the circle
     * doesn't happen to the square
     * @param b 
     */
    protected void visibility(boolean b) {
        square.setVisible(b);
    }

} // End Subclass SquarePane

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/