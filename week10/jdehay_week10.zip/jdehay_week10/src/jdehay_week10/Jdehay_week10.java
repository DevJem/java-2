package jdehay_week10;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: jdehay_week10
 *  @Date: Apr 8, 2018
 *  @Description: This program generates a random array list of LIST_SIZE numbers
 *          from 0 to 99. It then sends that array list to the sorting hat
 *          class, which copies the array list to perform each of the following
 *          on it: Insertion sort, Bubble Sort, Merge Sort, Quick Sort, 
 *          Heap Sort, Bucket Sort, and Radix Sort, and displays them on a GUI
 *  @Note: This program was written on a Linux build
 */

//Imports
import java.util.ArrayList;
import java.util.Iterator;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week10
public class Jdehay_week10 extends Application {
    
    // global declarations
    private static TextField tfOriginal = new TextField();
    private static TextArea taInsertion = new TextArea();
    private static TextArea taBubble = new TextArea();
    private static TextArea taMerge = new TextArea();
    private static TextArea taQuick = new TextArea();
    private static TextArea taHeap = new TextArea();
    private static TextArea taBucket = new TextArea();
    private static TextArea taRadix = new TextArea();
    private static Button btnCreate = new Button("Create Array");
    private static Button btnSort = new Button("Sort");
    private static Button btnClear = new Button("Clear");
    private static Button btnExit = new Button("Exit");
    private static ArrayList<Integer> list = new ArrayList<>();
    private static final int LIST_SIZE = 14;

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(700);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Sorting");
        Text topText2 = new Text("Click create array then click sort");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        GridPane middle = new GridPane();
        middle.setPadding(new Insets(5));
        middle.setAlignment(Pos.CENTER);
        middle.setVgap(6);
        middle.setStyle("-fx-border-color: red;");
        
        // Wrap textareas and prevent editing
        int textareaHeight = 50;
        tfOriginal.setEditable(false);
        
        taInsertion.setWrapText(true);
        taInsertion.setEditable(false);
        taInsertion.setPrefHeight(textareaHeight);
        
        taBubble.setWrapText(true);
        taBubble.setEditable(false);
        taBubble.setPrefHeight(textareaHeight);
        
        taMerge.setWrapText(true);
        taMerge.setEditable(false);
        taMerge.setPrefHeight(textareaHeight);
        
        taQuick.setWrapText(true);
        taQuick.setEditable(false);
        taQuick.setPrefHeight(textareaHeight);
        
        taHeap.setWrapText(true);
        taHeap.setEditable(false);
        taHeap.setPrefHeight(textareaHeight);
        
        taBucket.setWrapText(true);
        taBucket.setEditable(false);
        taBucket.setPrefHeight(textareaHeight);
        
        taRadix.setWrapText(true);
        taRadix.setEditable(false);
        taRadix.setPrefHeight(textareaHeight);
        
        // make labels
        int iLblWidth = 100;    // width of labels
        
        Label lblOriginal = new Label("Original Array:");
        lblOriginal.setPrefWidth(iLblWidth);
        Label lblInsertion = new Label("Insertion Sort:");
        lblInsertion.setPrefWidth(iLblWidth);
        Label lblBubble = new Label("Bubble Sort:");
        lblBubble.setPrefWidth(iLblWidth);
        Label lblMerge = new Label("Merge Sort:");
        lblMerge.setPrefWidth(iLblWidth);
        Label lblQuick = new Label("Quick Sort:");
        lblQuick.setPrefWidth(iLblWidth);
        Label lblHeap = new Label("Heap Sort:");
        lblHeap.setPrefWidth(iLblWidth);
        Label lblBucket = new Label("Bucket Sort:");
        lblBucket.setPrefWidth(iLblWidth);
        Label lblRadix = new Label("Radix Sort:");
        lblRadix.setPrefWidth(iLblWidth);
        
        // make center
        middle.add(lblOriginal, 0, 0);
        middle.add(tfOriginal, 1, 0, 8, 1);
        
        middle.add(lblInsertion, 0, 1);
        middle.add(taInsertion, 1, 1, 8, 1);
        
        middle.add(lblBubble, 0, 2);
        middle.add(taBubble, 1, 2, 8, 1);
        
        middle.add(lblMerge, 0, 3);
        middle.add(taMerge, 1, 3, 8, 1);
        
        middle.add(lblQuick, 0, 4);
        middle.add(taQuick, 1, 4, 8, 1);
        
        middle.add(lblHeap, 0, 5);
        middle.add(taHeap, 1, 5, 8, 1);
        
        middle.add(lblBucket, 0, 6);
        middle.add(taBucket, 1, 6, 8, 1);
        
        middle.add(lblRadix, 0, 7);
        middle.add(taRadix, 1, 7, 8, 1);
        
        // add middle to container
        container.getChildren().add(middle);

        /**
         * Bottom
         */
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(40);
        btnCreate.requestFocus();

        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        // make buttons do stuff
        btnCreate.setOnAction(new CreateHandler());
        btnSort.setOnAction(new SortHandler());
        btnClear.setOnAction(new ClearHandler());

        // add buttons to bottom and bottom to container
        bottom.getChildren().addAll(btnCreate, btnSort, btnClear, btnExit);
        container.getChildren().add(bottom);

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Sorting");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    private static void MyAlert(String body) {

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Error, Error...");
        alert.setContentText(body);
        alert.showAndWait();
    }  // End Alert Method

    /**
     * If there is no array created, creates an array [LIST_SIZE] of integers
     * between 0 and 99.
     */
    private static class CreateHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            
            if (!tfOriginal.getCharacters().toString().matches("")) {
                Jdehay_week10.MyAlert("Array already exists. Clear the array \n"
                        + "before creating a new one!");
                return;
            }
            
            // fill the list with random numbers
            for (int i = 0; i < LIST_SIZE; i++) {
                list.add((int) (Math.random() * 100));
            }
            
            Iterator iter = list.iterator();
            
            while (iter.hasNext()) {
                tfOriginal.appendText(iter.next().toString() + " ");
            }
        }
    }  // end Create Handler

    /**
     * uses the sorting hat class to output the sorted array with the appropriate
     * sorting method to the appropriate text area
     */
    private static class SortHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            
            if (tfOriginal.getCharacters().toString().matches("")) {
                Jdehay_week10.MyAlert("Nothing to sort!\nCreate an array first!");
                return;
            }
                        
            SortingHat sort = new SortingHat(list);
            sort.insertionSort(taInsertion);
            sort.bubbleSort(taBubble);
            sort.mergeSort(taMerge);
            sort.quickSort(taQuick);
            sort.heapSort(taHeap);
            sort.bucketSort(taBucket, LIST_SIZE);
            sort.radixSort(taRadix);
        }
    }  // end Sort Handler

    /**
     * Clears all fields if there's anything there
     */
    private static class ClearHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            
            if (tfOriginal.getCharacters().toString().matches("")) {
                Jdehay_week10.MyAlert("Nothing to clear!\nCreate an array first!");
                return;
            }
            
            tfOriginal.clear();
            taInsertion.clear();
            taBubble.clear();
            taMerge.clear();
            taQuick.clear();
            taHeap.clear();
            taBucket.clear();
            taRadix.clear();
            list.clear();
            btnCreate.requestFocus();
        }
    }  // end Clear Handler
}  //End Class Jdehay_week10

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */