package jdehay_week10;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week10
 * @Date: Apr 9, 2018
 * @Subclass SortingHat Description: All sorting methods sourced from
 * introduction to Java Programming Comprehensive Version by Y. Daniel Liang or
 * were provided by Professor Hickey or found on the Internet (source added)
 */

//Imports
import java.util.ArrayList;
import java.util.Iterator;
import javafx.scene.control.TextArea;

//Begin Subclass SortingHat
class SortingHat {

    private ArrayList<Integer> list = new ArrayList<>();

    // constructor
    SortingHat(ArrayList<Integer> list) {
        this.list = list;
    }

    // output method for array lists
    private void output(TextArea ta, double result, ArrayList<Integer> list) {
        ta.clear();
        Iterator iter = list.iterator();
        ta.setText("Sorted Array: ");

        while (iter.hasNext()) {
            ta.appendText(iter.next().toString() + " ");
        }

        ta.appendText("Ran at " + result + " nano seconds");
    }

    /**
     * Begin sorting methods
     */
    
    // insertion sort
    void insertionSort(TextArea ta) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();

        for (int i = 0; i < tempList.size(); i++) {
            int current = tempList.get(i);
            int k;
            for (k = i - 1; k >= 0 && tempList.get(k) > current; k--) {
                tempList.set(k + 1, tempList.get(k));
            }
            tempList.set(k + 1, current);
        }
        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }  // End insertion sort

    // bubble sort
    void bubbleSort(TextArea ta) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();
        boolean notDone = true;

        for (int k = 1; k < tempList.size() && notDone; k++) {
            notDone = false;
            for (int i = 0; i < tempList.size() - 1; i++) {
                if (tempList.get(i) > tempList.get(i + 1)) {
                    int temp = tempList.get(i);
                    tempList.set(i, tempList.get(i + 1));
                    tempList.set(i + 1, temp);
                    notDone = true;
                }
            }
        }
        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }  // End bubble sort

    // merge sort
    /**
     * Merge methods modified from examples provided. Thank you, Professor
     * Hickey
     *
     */
    void mergeSort(TextArea ta) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();

        mSort(tempList);

        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }

    private void mSort(ArrayList<Integer> list) {
        mSortPrime(list, 0, (list.size() - 1));
    }

    private void mSortPrime(ArrayList<Integer> list, int low, int high) {

        if (low < high && (high - low) >= 1) {
            int mid = (high + low) / 2;
            mSortPrime(list, low, mid);
            mSortPrime(list, mid + 1, high);

            //merging Sorted array produce above into one sorted array
            mergeIt(list, low, mid, high);
        }
    }

    private void mergeIt(ArrayList<Integer> list, int left, int mid, int right) {
        //Below is the mergedarray that will be sorted array Array[i-mid] , Array[(mid+1)-right]
        ArrayList<Integer> mergedSortedArray = new ArrayList<>();

        int leftIndex = left;
        int rightIndex = mid + 1;

        while (leftIndex <= mid && rightIndex <= right) {
            if (list.get(leftIndex) <= list.get(rightIndex)) {
                mergedSortedArray.add(list.get(leftIndex));
                leftIndex++;
            } else {
                mergedSortedArray.add(list.get(rightIndex));
                rightIndex++;
            }
        }

        //Either of below while loop will execute
        while (leftIndex <= mid) {
            mergedSortedArray.add(list.get(leftIndex));
            leftIndex++;
        }

        while (rightIndex <= right) {
            mergedSortedArray.add(list.get(rightIndex));
            rightIndex++;
        }

        int i = 0;
        int j = left;
        //Setting sorted array to original one
        while (i < mergedSortedArray.size()) {
            list.set(j, mergedSortedArray.get(i++));
            j++;
        }
    } //End mergeIt method and Merge Sort

    // quick sort
    /**
     * These methods modified from listing 23.8
     */
    void quickSort(TextArea ta) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();

        quickSort(tempList);

        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }

    private void quickSort(ArrayList<Integer> list) {
        quickSort(list, 0, list.size() - 1);

    }

    // recursively calls this method to partition the list around a pivot element
    private void quickSort(ArrayList<Integer> list, int first, int last) {
        if (last > first) {
            int pivotIndex = partition(list, first, last);
            quickSort(list, first, pivotIndex - 1);
            quickSort(list, pivotIndex + 1, last);
        }
    }

    // splits the list and performs the sorting
    private int partition(ArrayList<Integer> list, int first, int last) {
        int pivot = list.get(first);
        int low = first + 1;
        int high = last;

        while (high > low) {
            // search forward through the list
            while (low <= high && list.get(low) <= pivot) {
                low++;
            }

            // search backward through the list
            while (low <= high && list.get(high) > pivot) {
                high--;
            }

            // swap two elements
            if (high > low) {
                int temp = list.get(high);
                list.set(high, list.get(low));
                list.set(low, temp);
            }
        }

        while (high > first && list.get(high) >= pivot) {
            high--;
        }

        // swap pivot with list.get(high)
        if (pivot > list.get(high)) {
            list.set(first, list.get(high));
            list.set(high, pivot);
            return high;
        }
        return first;
    }  // End quick sort

    
    // heap sort
    /**
     * code from listing 23.10
     */
    void heapSort(TextArea ta) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();

        heapSort(tempList);

        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }

    private <E extends Comparable<E>> void heapSort(ArrayList<E> list) {

        Heap<E> heap = new Heap<>();

        // add elements to heap
        for (int i = 0; i < list.size(); i++) {
            heap.add(list.get(i));
        }

        // remove elements from heap
        for (int i = list.size() - 1; i >= 0; i--) {
            list.set(i, heap.remove());
        }
    }  // End heap sort

    // bucket sort
    /**
     * Bucket sort methods modified from examples provided.
     * 
     */
    void bucketSort(TextArea ta, int LIST_SIZE) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();

        bucketSort(tempList);

        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }

    private void bucketSort(ArrayList<Integer> list) {
        /* Find the max value of the array */
        int max = Integer.MIN_VALUE;
        for (Integer list1 : list) {
            if (list1 > max) {
                max = list1;
            }
        }
        /* Send array and max value to bucketSort sort method */
        bucketSort(list, max);
    }

    private void bucketSort(ArrayList<Integer> list, int max) {
        /* Create empty buckets */
        int[] bucket = new int[max + 1];    //Range is 0 to max
        for (int i = 0; i < bucket.length; i++) {
            bucket[i] = 0; //Initialize all buckets to 0
        }

        /* Place array elements into buckets */
        list.stream().forEach((list1) -> {
            bucket[list1]++;
        });

        /* Place results back into array using Insertion sort */
        int outPos = 0;
        for (int i = 0; i < bucket.length; i++) {
            for (int j = 0; j < bucket[i]; j++) {
                list.set(outPos++, i);
            }
        }
    }  // End bucket sort

    // radix sort
    /**
     * This sort (and a lot of knowledge) was sourced from Mishra, Neeraj.
     * “Radix Sort Java Program and Algorithm.” The Crazy Programmer, 27 Feb.
     * 2017,
     * www.thecrazyprogrammer.com/2015/06/radix-sort-java-program-and-algorithm.html.
     *
     */
    void radixSort(TextArea ta) {
        ArrayList<Integer> tempList = new ArrayList<>(list);
        double sTime = System.nanoTime();

        radixSort(tempList);

        double fTime = System.nanoTime();
        double result = fTime - sTime;
        output(ta, result, tempList);
    }

    private void radixSort(ArrayList<Integer> list) {
        int i, m = list.indexOf(list.get(0)), exp = 1, n = list.size();
        int[] b = new int[list.size()];

        for (i = 1; i < n; i++) {
            if (list.get(i) > m) {
                m = list.get(i);
            }
        }

        while (m / exp > 0) {
            int[] bucket = new int[10];

            for (i = 0; i < n; i++) {
                bucket[(list.get(i) / exp) % 10]++;
            }
            for (i = 1; i < 10; i++) {
                bucket[i] += bucket[i - 1];
            }
            for (i = n - 1; i >= 0; i--) {
                b[--bucket[(list.get(i) / exp) % 10]] = list.get(i);
            }
            for (i = 0; i < n; i++) {
                list.set(i, b[i]);
            }
            exp *= 10;
        }
    }  // End Radix Sort
} // End Subclass SortingHat

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
