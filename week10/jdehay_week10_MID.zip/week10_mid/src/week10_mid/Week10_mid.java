package week10_mid;

import java.util.ArrayList;
import java.util.Random;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: week10_mid
  *  @Date: Mar 25, 2018
  *  @Description:
  */
//Imports

//Begin Class Week10_mid
public class Week10_mid {
    
    static final int ARRAY_NUM = 16;
    static final int MAX = 100;
    static final int MIN = 0;
    static Random rand = new Random();

    //Begin Main Method
    public static void main(String[] args) {
        //Declare array with elements
        ArrayList<Integer> aList = new ArrayList<>();

        for (int i = 0; i < ARRAY_NUM; i++) {
            int randomNum = rand.nextInt((MAX - MIN) + 1) + MIN;
            aList.add(randomNum);
        }
        
        //Outer for loops: number of runs through array
        for (int i = 0; i < aList.size(); i++) {
            int index = i;
            //Inner for loop: finds lowest element value in array
            for (int x = i + 1; x < aList.size(); x++) {
                if (aList.get(x) < aList.get(index)) { //Is next number less than current?
                    index = x; //If so, set current to low
                }
            }
            
            //Set lowest element vlaue found to array location
            int lowNum = aList.get(index);
            aList.set(index, aList.get(i));
            aList.set(i, lowNum);
        }
        
        //Print sorted array
        for (int i = 0; i < aList.size(); i++) {
            if (i == aList.size() - 1) { //If last element, do not include comma
                System.out.printf(" %d\n", aList.get(i));
            } else {
                System.out.printf(" %d, ", aList.get(i));
            }
        }
    }  //End Main Method

}  //End Class Week10_mid

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/