package jdehay_week5;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: jdehay_week5
 *  @Date: Feb 28, 2018
 *  @Description: This is a GUI program that will allow the user to enter
 *          an integer and display the resulting binary conversion of it
 *          as well as the math for each result
 *  @Note: This program was written on a Linux build
 */

//Imports
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week5
public class Jdehay_week5 extends Application {
    // global declarations
    private static TextField tfInteger = new TextField();
    private static TextArea taBinary = new TextArea();
    private static ArrayList<String> alOutput = new ArrayList<>();
    
    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(500);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Binary Converter");
        Text topText2 = new Text("Please enter an Integer and click Convert");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox(10);
        middle.setPadding(new Insets(5));

        /**
         * Left
         */
        VBox left = new VBox(20);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.CENTER);
        left.setPrefWidth(225);

        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label enter = new Label("Enter an Integer:   ");
        tfInteger.requestFocus();
        tfInteger.setPrefWidth(80);
        leftTop.getChildren().addAll(enter, tfInteger);
        left.getChildren().add(leftTop);
        ImageView img = new ImageView(new Image("jdehay_week5/sauron.jpg"));
        left.getChildren().add(img);

        middle.getChildren().add(left);
        container.getChildren().add(middle);

        /**
         * Right
         */
        taBinary.setEditable(false);
        taBinary.setStyle("-fx-border-color: red;");
        middle.getChildren().add(taBinary);

        /**
         * Bottom
         */
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(80);

        Button btnConvert = new Button("Convert");
        Button btnClear = new Button("Clear");
        Button btnExit = new Button("Exit");
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });
        
        btnConvert.setOnAction(new convertHandler());
        btnClear.setOnAction(new clearHandler());
        
        bottom.getChildren().addAll(btnConvert, btnClear, btnExit);
        container.getChildren().add(bottom);

        /**
         * 
         * Place everything together and show it
         * 
         */ 
        Scene scene = new Scene(container);
        
        primaryStage.setTitle("Binary Converter");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }  // End start method

    /**
     * Convert the entry into binary
     * @param entry 
     */
    private static void convert(int entry) {
        int remainder;
        
        if (entry == 0) {
            return;
        }
        
        remainder = entry % 2;
        // populate arraylist with the remainders
        alOutput.add(String.valueOf(remainder));
        print(entry, remainder);
        convert(entry / 2);
    }
    
    /**
     * Prints out the binary conversion to the text area
     * @param entry
     * @param remainder 
     */
    private static void print(int entry, int remainder) {
        int result = entry/2;
        taBinary.appendText(entry + "/2 =\t" + result + " Remainder " + remainder + "\n");
    }

    /**
     * Handles what happens when the convert button is pressed
     */
    private static class convertHandler implements EventHandler<ActionEvent> {

        public convertHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            // must have whole numbers only
            if (!tfInteger.getCharacters().toString().matches("^\\d*$")
                    || tfInteger.getCharacters().toString().isEmpty()) {
                Alert noNumbers = new Alert(Alert.AlertType.WARNING);
                noNumbers.setTitle("Warning");
                noNumbers.setHeaderText("Enter numbers only!");
                noNumbers.showAndWait();
                tfInteger.requestFocus();
                return;
            }
            
            // get the integer and convert it
            Jdehay_week5.convert(Integer.parseInt(tfInteger.getCharacters().toString()));
            
            // print out the result
            Iterator<String> iter = alOutput.iterator();
            taBinary.appendText("-------------------------------------------"
                    + "\nResult: ");
            Collections.reverse(alOutput);
            
            while(iter.hasNext()) {
                taBinary.appendText(iter.next());
            }
            
        }
    }

    /**
     * Handles the clear button
     */
    private static class clearHandler implements EventHandler<ActionEvent> {

        public clearHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            tfInteger.clear();
            taBinary.clear();
            tfInteger.requestFocus();
        }
    }
}  //End Class Jdehay_week5

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */