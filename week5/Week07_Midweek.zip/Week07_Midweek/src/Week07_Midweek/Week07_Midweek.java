package Week07_Midweek;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Steven Hickey
 * @Assignment Name: test
 * @Date: Feb 15, 2017
 * @Description: Samples
 */
//Imports
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

//Begin Class Week07_Midweek
public class Week07_Midweek {

    //Begin Main Method
    public static void main(String[] args) {

        printOut();
        printOut2();
        printOut3();
    }

    private static void printOut() {

        Deque deq = new LinkedList();

        deq.add(10);
        deq.addFirst(12);
        deq.addLast(11);

        Iterator iter = deq.iterator();
        while (iter.hasNext()) {
            System.out.printf("%d\n", iter.next());
        }
    }

    private static void printOut2() {

        Deque list = new LinkedList();
        
        list.add(10);
        list.addFirst(12);
        list.addLast(11);
        Iterator iter = list.iterator();
        while (iter.hasNext()) {
            System.out.printf("%d\n", iter.next());
        }

    }

    private static void printOut3() {
        
        List list = new LinkedList();
        
        list.add(10);
        list.add(11);
        list.add(12);
        for (int i = 0; i < list.size(); i++) {
            System.out.printf("%d\n", list.get(i));
        }
    }

} //End Class Week07_Midweek
