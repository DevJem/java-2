package jdehay_week6;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: jdehay_week6
 *  @Date: Mar 4, 2018
 *  @Description: This program uses a generic subclass to add different
 *          objects to an arraylist and perform operations on them.
 *          It allows a user to enter at least one the following: string, 
 *          integer, and double, validates the entry, adds the entry to the 
 *          list, and displays them in a textarea.
 *  @Note: This program was written on a Linux build
 */

//Imports
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week6
public class Jdehay_week6 extends Application {
    
    // Global declarations
    private static TextField tfString = new TextField();
    private static TextField tfInteger = new TextField();
    private static TextField tfDouble = new TextField();
    private static TextArea taResult = new TextArea();
    private static Generic<Object> generic = new Generic<>();
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(500);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Generic Class Implementation");
        Text topText2 = new Text("Enter a character, word, or number of any "
                + "type and click enter");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox(10);
        middle.setPadding(new Insets(5));

        /**
         * Left
         */
        int iLblWidth = 130;    // width of labels
        int iTfWidth = 90;      // width of textfields
        
        // container for left side
        VBox left = new VBox(20);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.CENTER); 
        left.setPrefWidth(550);

        // String entry
        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label lblTop = new Label("Input a String: ");
        lblTop.setPrefWidth(iLblWidth);
        tfString.requestFocus();
        tfString.setPrefWidth(iTfWidth);
        leftTop.getChildren().addAll(lblTop, tfString);
        
        // Integer entry
        HBox leftMid = new HBox();
        leftMid.setAlignment(Pos.CENTER_LEFT);
        Label lblMid = new Label("Input an Integer: ");
        lblMid.setPrefWidth(iLblWidth);
        tfInteger.setPrefWidth(iTfWidth);
        leftMid.getChildren().addAll(lblMid, tfInteger);
        
        // Double entry
        HBox leftBottom = new HBox();
        leftBottom.setAlignment(Pos.CENTER_LEFT);
        Label lblBottom = new Label("Input a Double: ");
        lblBottom.setPrefWidth(iLblWidth);
        tfDouble.setPrefWidth(iTfWidth);
        leftBottom.getChildren().addAll(lblBottom, tfDouble);
        
        // add labels and textfields to left
        left.getChildren().addAll(leftTop, leftMid, leftBottom);
        
        // add left to middle
        middle.getChildren().add(left);

        /**
         * Right
         */
        taResult.setEditable(false);
        taResult.setStyle("-fx-border-color: red;");
        taResult.setWrapText(true);  // word wrap instead of scrolling
        middle.getChildren().add(taResult);
        
        // add middle to container
        container.getChildren().add(middle);

        /**
         * Bottom
         */
        // container for bottom
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(60);

        // make buttons
        Button btnEnter = new Button("Enter");
        Button btnClear = new Button("Clear");
        Button btnRemove = new Button("Remove");
        Button btnExit = new Button("Exit");
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });
        
        // make buttons do stuff
        btnEnter.setOnAction(new enterHandler());
        btnClear.setOnAction(new clearHandler());
        btnRemove.setOnAction(new removeHandler());
        
        // add buttons to bottom, add bottom to container
        bottom.getChildren().addAll(btnEnter, btnClear, btnRemove, btnExit);
        container.getChildren().add(bottom);

        /**
         * 
         * Place everything together and show it
         * 
         */ 
        Scene scene = new Scene(container);
        
        primaryStage.setTitle("Generic Class");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }  // End start method
    
    /**
     * method to produce an alert if something is wrong
     * @param content 
     */
    private static void raiseAlert(String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Input error");
        alert.setHeaderText("One or more entries have errors");
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Handles the enter button
     */
    private static class enterHandler implements EventHandler<ActionEvent> {
        
        @Override
        public void handle(ActionEvent event) {
            String alertContent = "";
            String sString = tfString.getCharacters().toString();
            String sInt = tfInteger.getCharacters().toString();
            String sDouble = tfDouble.getCharacters().toString();
            
            
            // handle string entry
            if (!sString.matches("^\\D*$") && !sString.isEmpty()) {
                alertContent += "Enter strings only in the string field\n";
            }
            
            // handle integer entry
            if (!sInt.matches("^\\d*$") && !sInt.isEmpty()) {
                alertContent += "Enter integers only in the integer field\n";
            } else if (!sInt.isEmpty() && Integer.parseInt(sInt) == 0) {
                alertContent += "Integer value cannot be zero!";
            }
            
            // handle double entry
            if (!sDouble.matches("^\\d*\\.\\d*$") && !sDouble.isEmpty()) {
                alertContent += "Enter floating point numbers only in the "
                        + "double field\n";
            } else if (!sDouble.isEmpty() && Double.parseDouble(sDouble) == 0.0) {
                alertContent += "Double value cannot be zero!";
            }
            
            // make sure at least one textfield is entered
            if (sString.isEmpty() && sInt.isEmpty() && sDouble.isEmpty()) {
                alertContent = "At least one field must be entered!\n";
            }
            
            // if there are no errors, push entered fields to the list
            // and output the list to the textarea and clear textfields
            if (!alertContent.equals("")) {
                Jdehay_week6.raiseAlert(alertContent);
            } else {
                if (!sString.isEmpty()) {
                    generic.push(sString + " ");
                }
                if (!sInt.isEmpty()) {
                    generic.push(sInt + " ");
                }
                if (!sDouble.isEmpty()) {
                    generic.push(sDouble + " ");
                }
                taResult.setText(generic.toString());
                tfString.clear();
                tfInteger.clear();
                tfDouble.clear();
            }
            tfString.requestFocus();
        }
    }

    /**
     * Handles the clear button
     */
    private static class clearHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            generic.clear();
            tfString.clear();
            tfInteger.clear();
            tfDouble.clear();
            taResult.clear();
            tfString.requestFocus();
        }
    }

    /**
     * Handles the remove button
     */
    private static class removeHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            
            if (!generic.isEmpty()) {
                generic.pop();
                taResult.setText(generic.toString());
            } else {
                Jdehay_week6.raiseAlert("Nothing to remove!");
            }
            tfString.requestFocus();
        }
    }
}  //End Class Jdehay_week6

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */