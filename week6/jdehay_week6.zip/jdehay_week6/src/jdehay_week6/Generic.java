package jdehay_week6;

import java.util.ArrayList;
import java.util.Iterator;

/**
  *  @param <E> generic object type
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week6
  *  @Date: Mar 4, 2018
  *  @Subclass Generic Description: generic class to handle lists of objects
  *         Copied from Listing 19.1 in Introduction to Java Programming by
  *         Y. Daniel Liang
  */
//Imports

//Begin Subclass Generic
public class Generic<E> {
    
    private ArrayList<E> list = new ArrayList<>();
    
    public void clear() {
        list.clear();
    }
    
    public int getSize() {
        return list.size();
    }
    
    public E peek() {
        return list.get(getSize() - 1);
    }
    
    public void push(E o) {
        list.add(o);
    }
    
    public E pop() {
        E o = list.get(getSize() - 1);
        list.remove(getSize() - 1);
        return o;
    }
    
    public boolean isEmpty() {
        return list.isEmpty();
    }
    
    @Override
    public String toString() {
        String listToString = "";
        Iterator it = list.iterator();
        while (it.hasNext()) {
            listToString += it.next();
        }
        return listToString;
    }

} // End Subclass Generic

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/