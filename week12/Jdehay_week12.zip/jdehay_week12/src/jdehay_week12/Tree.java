package jdehay_week12;

/**
 * @param <E>
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week12
 * @Date: Apr 21, 2018
 * @Subclass Tree Description: Copied from Listing 25.3 in Introduction to 
 *      Java Programming Comprehensive Version by Y. Daniel Liang
 */
//Imports
//Begin Subclass Tree
public interface Tree<E> extends Iterable<E> {

    /**
     * Return true if the element is in the tree
     * @param e
     * @return 
     */
    public boolean search(E e);

    /**
     * Insert element e into the binary search tree. Return true if the element
     * is inserted successfully.
     * @param e
     * @return 
     */
    public boolean insert(E e);

    /**
     * Delete the specified element from the tree. Return true if the element is
     * deleted successfully.
     * @param e
     * @return 
     */
    public boolean delete(E e);

    /**
     * Inorder traversal from the root
     */
    public void inorder();

    /**
     * Postorder traversal from the root
     */
    public void postorder();

    /**
     * Preorder traversal from the root
     */
    public void preorder();

    /**
     * Get the number of nodes in the tree
     * @return 
     */
    public int getSize();

    /**
     * Return true if the tree is empty
     * @return 
     */
    public boolean isEmpty();
}

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/
