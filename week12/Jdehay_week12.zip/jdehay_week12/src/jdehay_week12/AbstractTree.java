package jdehay_week12;

/**
 * @param <E>
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week12
 * @Date: Apr 20, 2018
 * @Subclass AbstractTree Description: Copied from Listing 25.4 in Introduction
 *      to Java Programming Comprehensive Version by Y. Daniel Liang
 */
//Imports
//Begin Subclass AbstractTree
public abstract class AbstractTree<E> implements Tree<E> {

    @Override
    /**
     * Inorder traversal from the root
     */
    public void inorder() {
    }

    @Override
    /**
     * Postorder traversal from the root
     */
    public void postorder() {
    }

    @Override
    /**
     * Preorder traversal from the root
     */
    public void preorder() {
    }

    @Override
    /**
     * Return true if the tree is empty
     */
    public boolean isEmpty() {
        return getSize() == 0;
    }
}

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/
