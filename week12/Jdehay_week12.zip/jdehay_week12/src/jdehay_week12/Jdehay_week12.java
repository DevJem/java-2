package jdehay_week12;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: jdehay_week12
 *  @Date: Apr 20, 2018
 *  @Description: This program fills an array with random numbers between 0 and
 *          99. It shows the random numbers generated, then shows them after
 *          they've been added to a BST with duplicates removed. Then it goes
 *          down the list and shows the depth of each node.
 *  @Note: This program was written on a Linux build
 */

//Imports
import java.util.ArrayList;
import java.util.Iterator;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week12
public class Jdehay_week12 extends Application {
    
    private static TextArea taRandom = new TextArea();
    private static TextArea taResult = new TextArea();
    private static Button btnMkTree = new Button("Make Tree");
    private static Button btnClear = new Button("Clear");
    private static Button btnExit = new Button("Exit");
    private static final int ARRAY_SIZE = 20;
    private static Integer[] iArray = new Integer[ARRAY_SIZE];
    private static BST tree;
    private static ArrayList list = new ArrayList();

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(500);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Binary Tree");
        Text topText2 = new Text("Perform Operations on a Binary Tree.\nClick "
                + "the Make Tree Button to Begin.");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox(5);
        middle.setPadding(new Insets(5));

        // Wrap textareas and prevent editing
        taRandom.setWrapText(true);
        taRandom.setEditable(false);
        taResult.setWrapText(true);
        taResult.setEditable(false);

        /**
         * Left
         */

        // container for left side
        VBox left = new VBox(10);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.TOP_CENTER);

        // Random numbers
        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        leftTop.getChildren().add(taRandom);
        left.getChildren().add(leftTop);

        // Buttons
        FlowPane leftMid = new FlowPane();
        leftMid.setHgap(6);
        leftMid.setAlignment(Pos.CENTER);
        leftMid.getChildren().addAll(btnMkTree, btnClear, btnExit);
        left.getChildren().add(leftMid);        

        // Image
        ImageView imgTree = new ImageView(new Image("jdehay_week12/tree.jpg"));
        left.getChildren().add(imgTree);

        // add left to middle
        middle.getChildren().add(left);

        /**
         * Right
         */
        VBox right = new VBox(10);
        right.setPadding(new Insets(5));
        right.setStyle("-fx-border-color: red;");
        taResult.setPrefHeight(500);
        taResult.setPrefWidth(800);
        right.getChildren().add(taResult);
        middle.getChildren().add(right);

        // add middle to container
        container.getChildren().add(middle);


        // make buttons do stuff
        btnMkTree.setOnAction(new MakeTreeHandler());
        btnClear.setOnAction(new ClearHandler());
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Binary Trees");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    /**
     * Handles Make tree button
     */
    private static class MakeTreeHandler implements EventHandler<ActionEvent> {

        public MakeTreeHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            fillArray();  // generates random numbers for the array
            taRandom.setText("The Array of Random Numbers Contains:\n\n");
            // displays the random array
            for (int i = 0; i < ARRAY_SIZE; i++) {
                if (i == ARRAY_SIZE - 1)
                    taRandom.appendText(String.valueOf(iArray[i]));
                else
                    taRandom.appendText(String.valueOf(iArray[i]) + ", ");
            }
            tree = new BST(iArray);  // new BST from the array
            
            // print out the list
            taResult.setText("The tree contains the following nodes:\n\n");
            tree.inorder();
            list = tree.getList();
            for (int i = 0; i < list.size(); i++) {
                if (i == list.size() - 1) 
                    taResult.appendText(String.valueOf(list.get(i)));
                else 
                    taResult.appendText(String.valueOf(list.get(i)) + ", ");
            }
            
            // format and print the rest of the output
            taResult.appendText("\n\nNode\t->\t\tLocation\n-------------------"
                    + "-----------------------\n");
            String temp = null;

            Iterator listIter = list.iterator();
            int i = 0;
            ArrayList<BST.TreeNode<Integer>> path;
            while (listIter.hasNext()) {
                String item = listIter.next().toString();
                path = tree.path(Integer.parseInt(item));
                temp = String.valueOf(++i);
                taResult.appendText(temp + ")\t" + item + "\twas located at "
                        + "level: " + (path.size() - 1) + "\n");
            }
        }
        
        // RNG fill the array
        private void fillArray() {
            for (int i = 0; i < ARRAY_SIZE; i++) {
                iArray[i] = (int) (Math.random() * 100);
            }
        }
    }

    /**
     * Handles Clear button
     */
    private static class ClearHandler implements EventHandler<ActionEvent> {

        public ClearHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            taRandom.clear();
            taResult.clear();
            
        }
    }
}  //End Class Jdehay_week12

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */