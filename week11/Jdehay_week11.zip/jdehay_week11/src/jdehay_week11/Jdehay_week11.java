package jdehay_week11;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week11
 * @Date: Apr 13, 2018
 * @Description: This program takes a value in one field and populates a linked
 *          List with it. It can place items in spots held by other items
 *          and move the other items to the right if the list is not full.
 *          It can remove items when the node position is specified.
 * @Note: This program was written on a Linux build
 */
//Imports
import java.util.LinkedList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week11
public class Jdehay_week11 extends Application {

    // global declarations
    private static TextField tfNode0 = new TextField();
    private static TextField tfNode1 = new TextField();
    private static TextField tfNode2 = new TextField();
    private static TextField tfNode3 = new TextField();
    private static TextField tfNode4 = new TextField();
    private static TextField tfNode5 = new TextField();
    private static TextField tfNode6 = new TextField();
    private static TextField tfNode7 = new TextField();
    private static TextField tfNode8 = new TextField();
    private static TextField tfNode9 = new TextField();
    private static TextField tfValue = new TextField();
    private static TextField tfPosition = new TextField();
    private static MyLinkedList<Object> list = new MyLinkedList<>();
    private static LinkedList ll = new LinkedList();

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(900);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Implementing a Linked List");
        Text topText2 = new Text("Enter a number, Character or String, & its "
                + "desired location then click Enter");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Bottom
         */
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(5));
        grid.setVgap(6);
        grid.setHgap(4);
        grid.setStyle("-fx-border-color: red;");
//        grid.setGridLinesVisible(true);  // grid for troubleshooting

        int width = 60;
        tfValue.setPrefWidth(width);
        tfPosition.setPrefWidth(width);
        tfValue.requestFocus();

        // node textfields are not editable
        tfNode0.setEditable(false);
        tfNode1.setEditable(false);
        tfNode2.setEditable(false);
        tfNode3.setEditable(false);
        tfNode4.setEditable(false);
        tfNode5.setEditable(false);
        tfNode6.setEditable(false);
        tfNode7.setEditable(false);
        tfNode8.setEditable(false);
        tfNode9.setEditable(false);

        // make labels
        Label lblNode0 = new Label("Node 0");
        Label lblNode1 = new Label("Node 1");
        Label lblNode2 = new Label("Node 2");
        Label lblNode3 = new Label("Node 3");
        Label lblNode4 = new Label("Node 4");
        Label lblNode5 = new Label("Node 5");
        Label lblNode6 = new Label("Node 6");
        Label lblNode7 = new Label("Node 7");
        Label lblNode8 = new Label("Node 8");
        Label lblNode9 = new Label("Node 9");
        Label lblValue = new Label("Value: ");
        Label lblPosition = new Label("Position: ");

        // make buttons
        Button btnEnter = new Button("Enter");
        Button btnRemove = new Button("Remove");
        Button btnClear = new Button("Clear");
        Button btnExit = new Button("Exit");

        // set up the grid
        GridPane.setConstraints(lblNode0, 0, 0, 2, 1);
        GridPane.setConstraints(lblNode1, 2, 0, 2, 1);
        GridPane.setConstraints(lblNode2, 4, 0, 2, 1);
        GridPane.setConstraints(lblNode3, 6, 0, 2, 1);
        GridPane.setConstraints(lblNode4, 8, 0, 2, 1);
        GridPane.setConstraints(tfNode0, 0, 1, 2, 1);
        GridPane.setConstraints(tfNode1, 2, 1, 2, 1);
        GridPane.setConstraints(tfNode2, 4, 1, 2, 1);
        GridPane.setConstraints(tfNode3, 6, 1, 2, 1);
        GridPane.setConstraints(tfNode4, 8, 1, 2, 1);

        GridPane.setConstraints(lblNode5, 0, 2, 2, 1);
        GridPane.setConstraints(lblNode6, 2, 2, 2, 1);
        GridPane.setConstraints(lblNode7, 4, 2, 2, 1);
        GridPane.setConstraints(lblNode8, 6, 2, 2, 1);
        GridPane.setConstraints(lblNode9, 8, 2, 2, 1);
        GridPane.setConstraints(tfNode5, 0, 3, 2, 1);
        GridPane.setConstraints(tfNode6, 2, 3, 2, 1);
        GridPane.setConstraints(tfNode7, 4, 3, 2, 1);
        GridPane.setConstraints(tfNode8, 6, 3, 2, 1);
        GridPane.setConstraints(tfNode9, 8, 3, 2, 1);

        GridPane.setConstraints(lblValue, 0, 4, 1, 1);
        GridPane.setConstraints(tfValue, 1, 4, 1, 1);
        GridPane.setConstraints(lblPosition, 2, 4, 1, 1);
        GridPane.setConstraints(tfPosition, 3, 4, 1, 1);

        GridPane.setConstraints(btnEnter, 4, 4, 1, 1);
        GridPane.setConstraints(btnRemove, 5, 4, 1, 1);
        GridPane.setConstraints(btnClear, 6, 4, 1, 1);
        GridPane.setConstraints(btnExit, 7, 4, 1, 1);

        // add nodes to grid
        grid.getChildren().addAll(
                lblNode0, lblNode1, lblNode2, lblNode3, lblNode4,
                tfNode0, tfNode1, tfNode2, tfNode3, tfNode4,
                lblNode5, lblNode6, lblNode7, lblNode8, lblNode9,
                tfNode5, tfNode6, tfNode7, tfNode8, tfNode9,
                lblValue, tfValue, lblPosition, tfPosition,
                btnEnter, btnRemove, btnClear, btnExit);

        // add grid to container
        container.getChildren().add(grid);

        // Make buttons do stuff
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });
        btnEnter.setOnAction(new EnterHandler());
        btnRemove.setOnAction(new RemoveHandler());
        btnClear.setOnAction(new ClearHandler());

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Linked Lists");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    private static void MyAlert(String body) {

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Error, Error...");
        alert.setContentText(body);
        alert.showAndWait();
    }  // End Alert Method

    /**
     * Figures out which textfield the user is looking for.
     * @param i
     * @return 
     */
    private static TextField nodePicker(int i) {
        switch (i) {
            case 0:
                return tfNode0;
            case 1:
                return tfNode1;
            case 2:
                return tfNode2;
            case 3:
                return tfNode3;
            case 4:
                return tfNode4;
            case 5:
                return tfNode5;
            case 6:
                return tfNode6;
            case 7:
                return tfNode7;
            case 8:
                return tfNode8;
            case 9:
                return tfNode9;
        }
        return null;
    }  // End Nodepicker

    /**
     * Handle the enter button
     */
    private static class EnterHandler implements EventHandler<ActionEvent> {

        public EnterHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            
            // Alerts
            if (tfValue.getText().matches("")) {
                Jdehay_week11.MyAlert("You need something in the Value field.");
                return;
            }

            if (list.size() >= 10) {
                Jdehay_week11.MyAlert("List is full!");
                return;
            }
            if (!tfPosition.getText().matches("^\\d*$")) {
                Jdehay_week11.MyAlert("You need a positive integer in the Position field.");
                tfPosition.clear();
                tfPosition.requestFocus();
                return;
            }

            // Object entered in value textfield
            String value = tfValue.getCharacters().toString();
            TextField temp;

            // adds the value entered into the next open node unless a currently
            // occupied node is entered in the position field.
            if (tfPosition.getText().matches("^\\d+")) {
                int node = Integer.parseInt(tfPosition.getCharacters().toString());

                if (node >= 10) {
                    Jdehay_week11.MyAlert("Node " + node + " does not exist!");
                    tfPosition.clear();
                    tfPosition.requestFocus();
                    return;
                }
                list.add(value, node);
            } else {
                list.add(value);
            }
            
            // clears and rewrites the textfields
            ClearHandler.clear();
            
            for (int i = 0; i < list.size(); i++) {
                temp = Jdehay_week11.nodePicker(i);
                temp.setText(String.valueOf(list.get(i)));
            }

            tfValue.clear();
            tfPosition.clear();
            tfValue.requestFocus();
        }
    }

    /**
     * Handler the remove button
     */
    private static class RemoveHandler implements EventHandler<ActionEvent> {

        public RemoveHandler() {
        }

        @Override
        public void handle(ActionEvent event) {

            // Alerts
            if (!tfPosition.getText().matches("^\\d+$")) {
                Jdehay_week11.MyAlert("You need a positive integer in the Position field.");
                tfPosition.clear();
                tfPosition.requestFocus();
                return;
            }

            // Position entered
            int node = Integer.parseInt(tfPosition.getCharacters().toString());

            if (node >= 10) {
                Jdehay_week11.MyAlert("Node " + node + " does not exist!");
                tfPosition.clear();
                tfPosition.requestFocus();
                return;
            }

            // Textfield related to position entered
            TextField temp = Jdehay_week11.nodePicker(node);

            if (temp.getCharacters().toString().matches("")) {
                Jdehay_week11.MyAlert("Nothing to remove from Node " + node + "!");
                tfPosition.clear();
                tfPosition.requestFocus();
                return;
            }
            list.remove(node);
            
            // clears and rewrites the textfields
            ClearHandler.clear();
            
            for (int i = 0; i < list.size(); i++) {
                temp = Jdehay_week11.nodePicker(i);
                temp.setText(String.valueOf(list.get(i)));
                System.out.println(String.valueOf(list.get(i)));
            }

            tfPosition.clear();
            tfPosition.requestFocus();
        }
    }

    /**
     * Handle the clear button
     */
    private static class ClearHandler implements EventHandler<ActionEvent> {

        public ClearHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            clear();            
            list.clear();
        }
        
        // clears the textfields for rewrite without emptying the list
        public static void clear() {
            tfNode0.clear();
            tfNode1.clear();
            tfNode2.clear();
            tfNode3.clear();
            tfNode4.clear();
            tfNode5.clear();
            tfNode6.clear();
            tfNode7.clear();
            tfNode8.clear();
            tfNode9.clear();
            tfValue.clear();
            tfPosition.clear();
            tfValue.requestFocus();
            
        }
    }
}  //End Class Jdehay_week11

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
