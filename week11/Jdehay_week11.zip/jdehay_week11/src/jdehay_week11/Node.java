package jdehay_week11;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week11
  *  @Date: Apr 15, 2018
  *  @Subclass Node Description: Copied from the Linked List Implementation lecture
  */
//Imports

//Begin Subclass Node
public class Node {
    
    //Declarations
    Node next;      //Next node reference if exists - else Null
    Object data;    //Data of any type

    /**
     * Constructor
     * @param dataValue 
     */
    public Node(Object dataValue) {
        next = null;
        data = dataValue;
    }

    /**
     * Get method to return data
     * @return data
     */
    public Object getData() {
        return data;
    }

    /**
     * Set method to set data
     * @param dataValue 
     */
    @SuppressWarnings("unused")
    public void setData(Object dataValue) {
        data = dataValue;
    }

    /**
     * Get method to advance to the next node in the LinkedList
     * @return next node
     */
    public Node getNext() {
        return next;
    }

    /**
     * Set method to set the next node in the LinkedList
     * @param nextValue 
     */
    public void setNext(Node nextValue) {
        next = nextValue;
    }

} // End Subclass Node

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/