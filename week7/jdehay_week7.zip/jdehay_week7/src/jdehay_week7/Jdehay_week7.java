package jdehay_week7;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week7
 * @Date: Mar 7, 2018
 * @Description: This program sorts a list of names and ages by using a 
 *          subclass that implements Comparator and Comparable.
 * @Note: This program was written on a Linux build
 */

//Imports
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week7
public class Jdehay_week7 extends Application {

    private static TextField tfName = new TextField();
    private static TextField tfAge = new TextField();
    private static TextArea taResult = new TextArea();
    private static CheckBox chkAge;
    private static CheckBox chkName;
    private static CheckBox chkBothAge;
    private static CheckBox chkBothName;
    private static ToggleGroup group = new ToggleGroup();
    private static RadioButton rbAge;
    private static RadioButton rbName;
    private static RadioButton rbBothAge;
    private static RadioButton rbBothName;
    private static SortingHat sortingHat = new SortingHat();
    private static Button btnEnter = new Button("Enter");
    private static Button btnSort = new Button("Sort");
    private static Button btnClear = new Button("Clear");
    private static Button btnExit = new Button("Exit");

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(500);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Comparator/Comparable Interface");
        Text topText2 = new Text("Enter a name and age and click enter");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox(5);
        middle.setPadding(new Insets(5));

        /**
         * Left
         */
        int iLblWidth = 100;    // width of labels

        // container for left side
        VBox left = new VBox(10);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.CENTER);
        left.setPrefWidth(550);

        // name entry
        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label lblTop = new Label("Name: ");
        lblTop.setPrefWidth(iLblWidth);
        tfName.requestFocus();
        leftTop.getChildren().addAll(lblTop, tfName);

        // age entry
        HBox leftMid = new HBox();
        leftMid.setAlignment(Pos.CENTER_LEFT);
        Label lblMid = new Label("Age: ");
        lblMid.setPrefWidth(iLblWidth);
        leftMid.getChildren().addAll(lblMid, tfAge);

        // add labels and textfields to left
        left.getChildren().addAll(leftTop, leftMid);

        // boxes
        VBox boxes = new VBox(4);
        chkAge = new CheckBox("Age");
        chkName = new CheckBox("Name");
        chkBothAge = new CheckBox("Both by Age");
        chkBothName = new CheckBox("Both by Name");
        rbAge = new RadioButton("Age");
        rbName = new RadioButton("Name");
        rbBothAge = new RadioButton("Both by Age");
        rbBothName = new RadioButton("Both by Name");
        rbAge.setToggleGroup(group);
        rbName.setToggleGroup(group);
        rbBothAge.setToggleGroup(group);
        rbBothName.setToggleGroup(group);

        // create actions for boxes
        chkAge.setOnAction(new ChkAgeHandler());
        chkName.setOnAction(new ChkNameHandler());
        chkBothAge.setOnAction(new ChkBothAgeHandler());
        chkBothName.setOnAction(new ChkBothNameHandler());

        // create actions for radiobuttons
        rbAge.setOnAction(new RbAgeHandler());
        rbName.setOnAction(new RbNameHandler());
        rbBothAge.setOnAction(new RbBothAgeHandler());
        rbBothName.setOnAction(new RbBothNameHandler());

        // add all checkboxes and radiobuttons to boxes
        boxes.getChildren().addAll(chkAge, chkName, chkBothAge, chkBothName,
                rbAge, rbName, rbBothAge, rbBothName);

        // add boxes to left
        left.getChildren().add(boxes);

        // add left to middle
        middle.getChildren().add(left);

        /**
         * Right
         */
        taResult.setEditable(false);
        taResult.setStyle("-fx-border-color: red;");
        middle.getChildren().add(taResult);

        // add middle to container
        container.getChildren().add(middle);

        /**
         * Bottom
         */
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(40);

        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        btnEnter.setOnAction(new enterHandler());
        btnSort.setOnAction(new sortHandler());
        btnClear.setOnAction(new clearHandler());

        bottom.getChildren().addAll(btnEnter, btnSort, btnClear, btnExit);
        container.getChildren().add(bottom);

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Interface");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    /**
     * method to produce an alert if something is wrong
     *
     * @param content
     */
    private static void raiseAlert(String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Input error");
        alert.setHeaderText("One or more entries have errors");
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * clears all the checkboxes so only one can be selected at a time0
     */
    private static void clearCheckboxes() {
        chkAge.setSelected(false);
        chkName.setSelected(false);
        chkBothAge.setSelected(false);
        chkBothName.setSelected(false);
    }

    /**
     * Validates textfield entries first
     * enters the name and age to the list, clears the textfields and places
     * focus back on the name textfield
     */
    private static class enterHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            if (!tfName.getCharacters().toString().matches("^\\D+$")) {
                raiseAlert("Enter only letters for the Name\n");
                tfName.requestFocus();
                return;
            }
            if (!tfAge.getCharacters().toString().matches("^\\d+$")) {
                raiseAlert("Enter only numbers for Age\n");
                tfAge.requestFocus();
                return;
            }

            sortingHat.addPerson(tfName.getCharacters().toString(),
                    Integer.parseInt(tfAge.getCharacters().toString()));
            taResult.setText(sortingHat.unsorted());
            tfName.clear();
            tfAge.clear();
            tfName.requestFocus();
        }
    }

    /**
     * Handles the sort button
     */
    private static class sortHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            if (taResult.getText().isEmpty()) {
                raiseAlert("Nothing to sort!");
                return;
            }

            if (chkAge.isSelected()) {
                taResult.setText(sortingHat.sortNum());
            } else if (chkName.isSelected()) {
                taResult.setText(sortingHat.sortAlpha());
            } else if (chkBothAge.isSelected()) {
                taResult.setText(sortingHat.sortBothNum());
            } else if (chkBothName.isSelected()) {
                taResult.setText(sortingHat.sortBothAlpha());
            } else {
                raiseAlert("Must have checkbox checked in order to sort!");
            }
        }
    }

    /**
     * Handles the clear button
     */
    private static class clearHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            if (taResult.getText().isEmpty()) {
                raiseAlert("Nothing to clear!");
                return;
            }

            tfName.clear();
            tfAge.clear();
            chkAge.setSelected(false);
            chkName.setSelected(false);
            chkBothAge.setSelected(false);
            chkBothName.setSelected(false);
            rbAge.setSelected(false);
            rbName.setSelected(false);
            rbBothAge.setSelected(false);
            rbBothName.setSelected(false);
            taResult.clear();
            sortingHat.clearList();
            tfName.requestFocus();
        }
    }

    /**
     * the next four handlers just allow only one checkbox to be checked at a
     * time
     */
    private static class ChkAgeHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            chkAge.setSelected(true);
        }
    }

    private static class ChkNameHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            chkName.setSelected(true);
        }
    }

    private static class ChkBothAgeHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            chkBothAge.setSelected(true);
        }
    }

    private static class ChkBothNameHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            chkBothName.setSelected(true);
        }
    }

    /**
     * The next four handlers handle the automatic textarea adjustments when the
     * radiobuttons are clicked
     */
    private static class RbAgeHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            if (taResult.getText().isEmpty()) {
                raiseAlert("Nothing to sort!");
                return;
            }
            taResult.setText(sortingHat.sortNum());
        }

    }

    private static class RbNameHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            if (taResult.getText().isEmpty()) {
                raiseAlert("Nothing to sort!");
                return;
            }
            taResult.setText(sortingHat.sortAlpha());
        }

    }

    private static class RbBothAgeHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            if (taResult.getText().isEmpty()) {
                raiseAlert("Nothing to sort!");
                return;
            }
            taResult.setText(sortingHat.sortBothNum());
        }

    }

    private static class RbBothNameHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week7.clearCheckboxes();
            if (taResult.getText().isEmpty()) {
                raiseAlert("Nothing to sort!");
                return;
            }
            taResult.setText(sortingHat.sortBothAlpha());
        }

    }

}  //End Class Jdehay_week7

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
