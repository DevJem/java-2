package jdehay_week7;

/**
  *  @Course: SDEV 350 ~ Java Programming II
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week7
  *  @Date: Mar 7, 2018
  *  @Subclass Person Description: This class creates Person objects with 
  *             names and ages to be placed in a list in the sortinghat
  *             subclass. This code borrows heavily from the code in
  *             the Comparator Interface portion of week 7s lecture
  */

//Imports
import java.util.Comparator;

//Begin Subclass Person
class Person implements Comparator<Person>, Comparable<Person> {
    
    private String name;
    private int age;

    Person() {
        this(null, 0);
    }
    
    public Person(String n, int a) {
        this.name = n;
        this.age = a;
    }
    
    public String getPersonName() {
        return name;
    }
    
    public int getPersonAge() {
        return age;
    }

    @Override
    /**
     * returns names in alphabetical order
     * @param p
     * @return 
     */
    public int compareTo(Person p) {
        return (this.name).compareTo(p.name);
    }
    
    @Override
    /**
     * Return ages in numerical order
     * @param p
     * @param p1
     * @return 
     */
    public int compare(Person p, Person p1) {
        return p.age - p1.age;
    }
} // End Subclass Person

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/