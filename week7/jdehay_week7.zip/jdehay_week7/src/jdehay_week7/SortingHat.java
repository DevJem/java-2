package jdehay_week7;

/**
  *  @Course: SDEV 350 ~ Java Programming II
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week7
  *  @Date: Mar 7, 2018
  *  @Subclass SortingHat Description: This subclass creates and manipulates
  *             a list of the object subclass People. It includes methods
  *             to sort and display the list in various ways.
  */

//Imports
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

//Begin Subclass SortingHat
public class SortingHat {
    
    private List<Person> list = new ArrayList<>();
    
    void addPerson(String n, int a) {
        list.add(new Person(n, a));
    }
    
    public void clearList() {
        list.clear();
    }
    
    /**
     * initial, unsorted list
     * @return 
     */
    public String unsorted() {
        String result = "Unordered list of People:\n";
        for (Person p : list) {
            result += p.getPersonName() + " is " + p.getPersonAge() + " years old.\n";
        }
        return result;
    }
    
    /**
     * List of sorted ages
     * @return 
     */
    public String sortNum() {
        String result = "Ordered by Age:\n";
        Collections.sort(list, new Person());
        for (Person p : list) {
            result += p.getPersonAge() + "\n";
        }
        return result;
    }
    
    /**
     * List of names sorted alphabetically
     * @return 
     */
    public String sortAlpha() {
        String result = "Ordered by Name:\n";
        Collections.sort(list);
        for (Person p : list) {
            result += p.getPersonName() + "\n";
        }
        return result;
    }
    
    /**
     * Names and ages ordered by age when selected by rbBothAge or chkBothAge
     * @return 
     */
    public String sortBothNum() {
        String result = "Ordered by Age with Name: \n";
        Collections.sort(list, new Person());
        for (Person p : list) {
            result += p.getPersonName() + " is " + p.getPersonAge() + " years old\n";
        }
        return result;
    }
    
    /**
     * names and ages ordered by name
     * @return 
     */
    public String sortBothAlpha() {
        String result = "Ordered by Name with Age\n";
        Collections.sort(list);
        for (Person p : list) {
            result += p.getPersonName() + " is " + p.getPersonAge() + " years old\n";
        }
        return result;
    }
} // End Subclass SortingHat

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/