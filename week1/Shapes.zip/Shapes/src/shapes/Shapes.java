package shapes;

/**
 * @Course: SDEV 350 ~ Java Programming I
 * @Author Name: steven.hickey
 * @Assignment Name: shapes
 * @Date: Aug 20, 2015
 * @Description: Program used to demonstrate shape nodes.
 */
//Imports
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Polyline;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

//Begin Class Shapes
public class Shapes extends Application {

    @Override
    public void start(Stage primaryStage) {

        /* New pane */
        Pane root = new Pane();

        /**
         * Polygon & PolyLine
         */
        Polygon pG = new Polygon(80, 20, 120, 20, 140, 60, 120, 100, 80, 100, 60, 60);
        Polyline pL = new Polyline(230, 20, 270, 60, 250, 100, 210, 100, 190, 60);
        pG.setFill(Color.AQUA);
        pG.setStroke(Color.BLACK);
        pG.setStrokeWidth(2);
        pL.setFill(Color.RED);
        pL.setStroke(Color.BLACK);
        pL.setStrokeWidth(2);

        /**
         * Ellipse & Circle
         */
        Ellipse elip = new Ellipse(380, 60, 70, 40);
        elip.setFill(Color.CORNFLOWERBLUE);
        elip.setStroke(Color.BLACK);
        elip.setStrokeWidth(2);
        Circle cir = new Circle(100, 200, 40);
        cir.setFill(Color.DARKTURQUOISE);
        cir.setStroke(Color.BLACK);
        cir.setStrokeWidth(2);

        /**
         * Text
         * Each shape is labeled with a text node
         * A message node is also included
         */
        Text txtPolygon = new Text(77.5, 65, "Polygon");
        Text txtPolyLine = new Text(210, 65, "PolyLine");
        Text txtEllipse = new Text(365, 65, "Ellipse");
        Text txtLine = new Text(15, 137.5, "Line");
        Text txtCir = new Text(85, 205, "Circle");
        Text txtRec = new Text(85, 320, "Rectangle");
        Text txtSqr = new Text(217.5, 320, "Square");
        Text txtRndRec = new Text(345, 315, "Rounded\nRectangle");
        Text txtRArc = new Text(77.5, 375, "Arc\nType Round");
        Text txtOArc = new Text(210, 375, "Arc\nType Open");
        Text txtCArc = new Text(345, 375, "Arc\nType Chord");
        Text msg = new Text(170, 185,"This pane contains a sample of\neach shape discussed "
                + "in this week's\nlecture.");
        msg.setFont(Font.font("TIMES NEW ROMAN", FontWeight.BOLD, FontPosture.ITALIC, 18));
        msg.setFill(Color.RED);

        /**
         * Line
         */
        Line line = new Line(50, 135, 400, 135);
        line.setStrokeWidth(2);

        /**
         * Rectangle, Rounded Rectangle, & Square
         */
        Rectangle rec = new Rectangle(60, 280, 100, 75);
        rec.setFill(Color.DARKCYAN);
        rec.setStroke(Color.BLACK);
        rec.setStrokeWidth(2);
        Rectangle sqr = new Rectangle(200, 280, 75, 75);
        sqr.setFill(Color.DARKGRAY);
        sqr.setStroke(Color.RED);
        sqr.setStrokeWidth(2);
        /* Begin Rounded Rectangle */
        Rectangle rRec = new Rectangle(320, 280, 100, 75);
        rRec.setArcHeight(25);
        rRec.setArcWidth(25);
        rRec.setFill(Color.DARKORANGE);
        rRec.setStroke(Color.BLACK);
        rRec.setStrokeWidth(2);
        /* End Rounded Rectangle */

        /**
         * Arcs
         */
        /* Round Arc */
        Arc arc2 = new Arc(60, 400, 60, 75, -85, 85);
        arc2.setFill(Color.BURLYWOOD);
        arc2.setStroke(Color.BLACK);
        arc2.setStrokeWidth(2);
        arc2.setType(ArcType.ROUND);
        /* Open Arc */
        Arc arc = new Arc(200, 400, 60, 75, -85, 85);
        arc.setFill(Color.BURLYWOOD);
        arc.setStroke(Color.BLACK);
        arc.setStrokeWidth(2);
        arc.setType(ArcType.OPEN);
        /* Chord Arc */
        Arc arc1 = new Arc(350, 400, 60, 75, -85, 85);
        arc1.setFill(Color.BURLYWOOD);
        arc1.setStroke(Color.BLACK);
        arc1.setStrokeWidth(2);
        arc1.setType(ArcType.CHORD);

        /* Add all nodes to the pane */
        root.getChildren().addAll(pG, pL, arc, arc1, arc2, elip, cir, line,
                rec, sqr, rRec, txtPolygon, txtPolyLine, txtEllipse, txtLine,
                txtCir,txtRec, txtSqr, txtRndRec,txtRArc, txtOArc, txtCArc, msg);

        /* Set Stage and Scene */
        Scene scene = new Scene(root, 500, 500);
        primaryStage.setTitle("Shapes");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
} //End Class Shapes
