package week1;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: week1
 *  @Date: Jan 18, 2018
 *  @Description: This program creates a non-operation GUI for practice with
 *          aligning layout panes and nodes.
 *  @Note: This program was written on a Linux build
 */

//Imports
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

//Begin Class Week1
public class Week1 extends Application {
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        primaryStage.setResizable(false);
        
        // contains the whole app
        BorderPane container = new BorderPane();
        container.setPadding(new Insets(20));
        
        /**
         * 
         * build the top
         * 
         */ 
        // top toptext
        Font top = Font.font("Serif", FontPosture.ITALIC, 40);
        Text topText1 = new Text("Welcome to Our Mailing List");
        topText1.setStyle("-fx-stroke: black; -fx-fill: #ab0000;");        
        topText1.setFont(top);
        
        // bottom toptext
        Text topText2 = new Text("Please fill out the information below and "
                + "click the Enter button");
        topText2.setFont(Font.font("Times New Roman", FontWeight.BOLD,
                FontPosture.ITALIC, 20));
        
        // put top toegether and set it
        VBox topbox = new VBox();
        topbox.setAlignment(Pos.CENTER);
        topbox.getChildren().add(topText1);
        topbox.getChildren().add(topText2);
        container.setTop(topbox);
        
        /**
         * 
         * build the bottom
         * 
         */ 
        // image
        ImageView img = new ImageView(new Image("week1/my_image.jpg"));
        
        // buttons
        VBox buttons = new VBox(15);
        buttons.setPadding(new Insets(10));
        buttons.getChildren().add(new Button("Enter"));
        buttons.getChildren().add(new Button("Clear"));
        buttons.getChildren().add(new Button("Exit  "));
        
        // put bottom together and set it
        HBox bottom = new HBox(40);
        bottom.setPadding(new Insets(10, 20, 20, 0));
        bottom.getChildren().add(buttons);
        bottom.getChildren().add(img);
        container.setBottom(bottom);
        
        /**
         * 
         * build the center
         * 
         */ 
        // grid
        GridPane center = new GridPane();
//        center.setGridLinesVisible(true);  // troubleshooting purposes
        center.setHgap(8);
        center.setVgap(5);
        center.setPadding(new Insets(10, 10, 10, 10));
        center.setStyle("-fx-border-color: red;");
        
        // name box
        Label fnLabel = new Label("First Name:");
        TextField fName = new TextField();
        Label lnLabel = new Label("Last Name:");
        TextField lName = new TextField();
        Label miLabel = new Label("MI:");
        TextField mName = new TextField();
        mName.setPrefWidth(40);
        
        
        GridPane.setConstraints(fnLabel, 0, 0, 2, 1);
        GridPane.setConstraints(fName, 2, 0);
        GridPane.setConstraints(lnLabel, 3, 0);
        GridPane.setConstraints(lName, 4, 0, 2, 1);
        GridPane.setConstraints(miLabel,  7, 0);
        GridPane.setConstraints(mName, 8, 0);
        
        // address 1
        Label add1Label = new Label("Street Address:");
        TextField add1 = new TextField();
        
        GridPane.setConstraints(add1Label, 0, 1, 2, 1);
        GridPane.setConstraints(add1, 2, 1, 7, 1);
        
        // address 2
        Label add2Label = new Label("Address Continued:");
        TextField add2 = new TextField();
        
        GridPane.setConstraints(add2Label, 0, 2, 2, 1);
        GridPane.setConstraints(add2, 2, 2, 7, 1);
        
        // city state zip
        Label cityLabel = new Label("City:");
        TextField city = new TextField();
        Label stateLabel = new Label("State:");
        ComboBox state = new ComboBox();
        Label zipLabel = new Label("Zip:");
        TextField zip = new TextField();
        
        GridPane.setConstraints(cityLabel, 0, 3);
        GridPane.setConstraints(city, 1, 3, 2, 1);
        GridPane.setConstraints(stateLabel, 3, 3);
        GridPane.setConstraints(state, 4, 3);
        GridPane.setConstraints(zipLabel, 5, 3);
        GridPane.setConstraints(zip, 6, 3, 3, 1);
        
        // phone number home/work/cell
        Label phLabel = new Label("Phone Number:");
        TextField phone = new TextField();
        
        /**
         * radiobutton would make more sense in this context but I included the
         * code for checkboxes as per the assignment.
         */
//        ToggleGroup group = new ToggleGroup();
//        RadioButton home = new RadioButton("Home");
//        RadioButton work = new RadioButton("Work");
//        RadioButton cell = new RadioButton("Cell");
//        home.setToggleGroup(group);
//        work.setToggleGroup(group);
//        cell.setToggleGroup(group);
        CheckBox home = new CheckBox("Home");
        CheckBox work = new CheckBox("Work");
        CheckBox cell = new CheckBox("Cell");
        
        GridPane.setConstraints(phLabel, 0, 4, 2, 1);
        GridPane.setConstraints(phone, 2, 4);
        GridPane.setConstraints(home, 3, 4);
        GridPane.setConstraints(work, 4, 4);
        GridPane.setConstraints(cell, 5, 4);
        
        // primary and secondary email
        Label pEmailLabel = new Label("Email Primary:");
        TextField pEmail = new TextField();
        Label sEmailLabel = new Label("Secondary:");
        TextField sEmail = new TextField();
        
        GridPane.setConstraints(pEmailLabel, 0, 5, 2, 1);
        GridPane.setConstraints(pEmail, 2, 5);
        GridPane.setConstraints(sEmailLabel, 3, 5);
        GridPane.setConstraints(sEmail, 4, 5, 5, 1);
        
        // put center together and set it
        center.getChildren().addAll(
                fnLabel, fName, lnLabel, lName, miLabel, mName,
                add1Label, add1, add2Label, add2,
                cityLabel, city, stateLabel, state, zipLabel, zip,
                phLabel, phone, home, work, cell,
                pEmailLabel, pEmail, sEmailLabel, sEmail
        );
        center.setAlignment(Pos.CENTER);
        
        container.setCenter(center);        
        
        /**
         * 
         * Place everything together and show it
         * 
         */ 
        Scene scene = new Scene(container);
        
        primaryStage.setTitle("Sign Up Today!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
    }  // End start method
}  //End Class Week1

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */