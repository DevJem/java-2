package jdehay_week9;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week9
 * @Date: Apr 4, 2018
 * @Description: this program takes in two user entered integers and displays
 * the GCD between the numbers. Then it shows the values of each prime number
 * between 0 and the entered number for both entries.
 * @Note: This program was written on a Linux build
 */
//Imports
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week9
public class Jdehay_week9 extends Application {

    // global declarations
    private static TextField tfFirst = new TextField();
    private static TextField tfSecond = new TextField();
    private static TextArea taResult = new TextArea();
    private static Button btnExecute = new Button("Execute");
    private static Button btnClear = new Button("Clear");
    private static Button btnExit = new Button("Exit");

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        VBox container = new VBox();
        container.setPrefWidth(650);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("Common Divisors & Primes");
        Text topText2 = new Text("Enter a number in each box, then click Execute");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox(5);
        middle.setPadding(new Insets(5));
        middle.setPrefHeight(200);

        // Wrap textarea and prevent editing
        taResult.setWrapText(true);
        taResult.setEditable(false);

        /**
         * Left
         */
        int iLblWidth = 180;    // width of labels

        // container for left side
        VBox left = new VBox(8);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.CENTER);
        left.setPrefWidth(300);

        // 1st number entry
        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label lblTop = new Label("1st Number: ");
        lblTop.setPrefWidth(iLblWidth);
        tfFirst.requestFocus();
        leftTop.getChildren().addAll(lblTop, tfFirst);

        // 2nd number entry
        HBox leftMid = new HBox();
        leftMid.setAlignment(Pos.CENTER_LEFT);
        Label lblMid = new Label("2nd Number: ");
        lblMid.setPrefWidth(iLblWidth);
        leftMid.getChildren().addAll(lblMid, tfSecond);

        // add labels and textfields to left
        left.getChildren().addAll(leftTop, leftMid);

        // add left to middle
        middle.getChildren().add(left);

        /**
         * Right
         */
        taResult.setStyle("-fx-border-color: red;");
        middle.getChildren().add(taResult);

        // add middle to container
        container.getChildren().add(middle);

        /**
         * Bottom
         */
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(40);

        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        // make buttons do stuff
        btnExecute.setOnAction(new ExecuteHandler());
        btnClear.setOnAction(new ClearHandler());

        // add buttons to bottom and bottom to container
        bottom.getChildren().addAll(btnExecute, btnClear, btnExit);
        container.getChildren().add(bottom);

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Maps");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    private static void MyAlert(String body) {

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Error, Error...");
        alert.setContentText(body);
        alert.showAndWait();

    }  // End Alert Method

    /**
     * Execute validates integer entries and sends them to be compared for their
     * GCD in one method and uses another method to find and output each prime
     * number from 0 to the entered number for both entries.
     */
    private static class ExecuteHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            // validations
            if (tfFirst.getCharacters().toString().equals("")) {
                MyAlert("1st Number needs an input!\n");
                tfFirst.requestFocus();
                return;
            }
            if (!tfFirst.getCharacters().toString().matches("^\\d+$")) {
                MyAlert("Please only enter whole numbers in 1st Number Input.\n");
                tfFirst.clear();
                tfFirst.requestFocus();
                return;
            }
            if (tfSecond.getCharacters().toString().equals("")) {
                MyAlert("2nd Number needs an input!\n");
                tfSecond.requestFocus();
                return;
            }
            if (!tfSecond.getCharacters().toString().matches("^\\d+$")) {
                MyAlert("Please only enter whole numbers in 2nd Number Input.\n");
                tfSecond.clear();
                tfSecond.requestFocus();
                return;
            }

            // simplify integers entered
            int iFirst = Integer.parseInt(tfFirst.getCharacters().toString());
            int iSecond = Integer.parseInt(tfSecond.getCharacters().toString());

            // output to the text area
            taResult.setText("The greatest common denominator between "
                    + iFirst + " and " + iSecond + " is: ");
            taResult.appendText(gcd(iFirst, iSecond));
            taResult.appendText(primes(iFirst));
            taResult.appendText(primes(iSecond));
        }

        // GCD code modified from Chapter 22 listing 22.4 of Introduction to Java
        // Programming Comprehensive Version by Y. Daniel Liang
        private String gcd(int first, int second) {

            if (first % second == 0) {

                return String.valueOf(second);
            } else {
                return gcd(second, first % second);
            }
        }

        // prime code modified from Chapter 22 listing 22.7 of Introduction to 
        // Java Programming Comprehensive Version by Y. Daniel Liang
        private String primes(int entry) {
            String result = "";
            int count = 0;
            result += "";
            boolean[] primes = new boolean[entry + 1];

            // initializes primes[] to true
            for (int i = 0; i < primes.length; i++) {
                primes[i] = true;
            }

            // removes elements that are unneccessary to test
            for (int k = 2; k <= entry / k; k++) {
                if (primes[k]) {
                    for (int i = k; i <= entry / k; i++) {
                        primes[k * i] = false;
                    }
                }
            }

            // adds results that are still true to the result string
            for (int i = 2; i < primes.length; i++) {
                if (primes[i]) {
                    count++;
                    result += i + " ";
                }
            }
            taResult.appendText("\n\nThere are " + count + " primes <= the "
                    + "number " + entry + "\n");
            return result;
        }
    }

    /**
     * clears the numbers entered and the result text area
     */
    private static class ClearHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            tfFirst.clear();
            tfSecond.clear();
            taResult.clear();
            tfFirst.requestFocus();
        }
    }
}  //End Class Jdehay_week9

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
