package jdehay_week4;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week4
 * @Date: Feb 26, 2018
 * @Subclass Open Description: This subclass receives a binary i/o file and
 *          transforms it to a readable text file
 */
//Imports
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

//Begin Subclass Open
class Open {

    /**
     * Receives the dat file and writes it to a readable file
     * @param file 
     */
    void transform(RandomAccessFile file) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter("ConvertedText.txt");
            try (BufferedWriter bw = new BufferedWriter(pw)) {
                for (int i = 0; 8 < file.length() / 4; i++) {
                    file.seek(i * 4);
                    String num = Integer.toString(file.readInt());
                    bw.write("Number at position " + i + ": " + num);
                    bw.newLine();
                }
            }
            pw.close();
        } catch (IOException ex) {
            pw.close();
        }
        try {
            openFiles();
        } catch (InterruptedException ex) {
            Logger.getLogger(Open.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Opens both files
     * @throws InterruptedException 
     */
    private void openFiles() throws InterruptedException {
        Runtime rs = Runtime.getRuntime();
        String fileText = "ConvertedText.txt";
        String fileDat = "numbers.dat";
        try {
            if (val.fileExit(fileText)) {
                Process p = rs.exec("xdg-open " + fileText);
//                System.out.println(p.isAlive());  // for testing
            } else {
                System.out.println("file not found");
            }
            if (val.fileExit(fileDat)) {
                Process p = rs.exec("/usr/bin/gedit " + fileDat);
//                System.out.println(p.isAlive());  // for testing
            } else {
                System.out.println("file not found");
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    private static class val {

        // Help from https://stackoverflow.com/a/17677850/4196281
        // Help from https://stackoverflow.com/a/15954821/4196281
        private static boolean fileExit(String fileName) {
            Path p = Paths.get("");
            String pwd = p.toAbsolutePath().toString();
//            System.out.println(pwd);  //for testing
            if (new File(pwd + "/" + fileName).exists()) {
                return true;
            }
            return false;
        }
    }

} // End Subclass Open

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/
