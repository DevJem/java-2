package jdehay_week4;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week4
 * @Date: Feb 26, 2018
 * @Subclass Go Description: This subclass handles what happens when the Go 
 *          button is pressed. It creates and writes to the file
 *          based on the integer sent from the main class. It then 
 *          has methods to navigate to certain parts of the file.
 */

//Imports
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.logging.Level;
import java.util.logging.Logger;

//Begin Subclass Go
public class Go {

    private int entry;
    private RandomAccessFile file;
    private int position;

    /**
     * Constructor receives the number from the main class and 
     * creates a new file
     * @param userEntry 
     */
    public Go(int userEntry) {
        entry = userEntry;

        try {
            this.file = new RandomAccessFile("numbers.dat", "rw");
        } catch (FileNotFoundException e) {

        }
    }

    /**
     * Returns the length of the file
     * @return
     * @throws IOException 
     */
    protected String fileLength() throws IOException {
        int test = 0;
        file.setLength(0);
        for (int i = 0; i < entry; i++) {
            test = (int) (Math.random() * 100);
            file.writeInt(test);
        }
        return String.valueOf(file.length());
    }

    /**
     * Returns the first integer
     * @return 
     */
    protected String firstInt() {
        try {
            file.seek(0);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    /**
     * Returns the second integer
     * @return 
     */
    protected String secondInt() {
        try {
            file.seek(1 * 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    /**
     * Returns the tenth integer
     * @return 
     */
    protected String tenthInt() {
        try {
            file.seek(9 * 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    /**
     * Returns the last integer
     * @return 
     */
    protected String lastInt() {
        try {
            file.seek(file.length() - 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    /**
     * Returns an integer at a random point in the file
     * @return 
     */
    protected String randomInt() {
        position = (int) (Math.random() * entry);
        try {
            file.seek(position * 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    /**
     * returns the position of the random integer
     * @return 
     */
    protected String getPosition() {
        return String.valueOf(position);
    }

    /**
     * returns the file
     * @return 
     */
    protected RandomAccessFile getFile() {
        return file;
    }

} // End Subclass Go

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/
