package jdehay_week4_SMH;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week4
 * @Date: Feb 17, 2018
 * @Description:
 * @Note: This program was written on a Linux build
 */
//Imports
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;

//Begin Class Jdehay_week4_SMH
public class Jdehay_week4_SMH extends Application {

    private static TextField tfInteger = new TextField();
    private static TextField tfFirst = new TextField();
    private static TextField tfSecond = new TextField();
    private static TextField tfTenth = new TextField();
    private static TextField tfLast = new TextField();
    private static TextField tfFileLength = new TextField();
    private static TextField tfRandom = new TextField();
    private static Open_SMH openButton = new Open_SMH();
    private static Go_SMH goButton;

    @Override
    public void start(Stage primaryStage) throws Exception {

        VBox container = new VBox();
        container.setPrefWidth(500);
        container.setPadding(new Insets(10));

        /**
         * Top
         */
        VBox top = new VBox();
        top.setPadding(new Insets(20));
        top.setAlignment(Pos.CENTER);
        Font topText1Font = Font.font("Serif", FontPosture.ITALIC, 30);
        Font topText2Font = Font.font("Serif", FontPosture.ITALIC, 15);
        Text topText1 = new Text("RandomAccessFile Exercise");
        Text topText2 = new Text("Please enter an Integer and click the Go button");
        topText1.setFont(topText1Font);
        topText2.setFont(topText2Font);
        top.getChildren().addAll(topText1, topText2);
        container.getChildren().add(top);

        /**
         * Middle
         */
        HBox middle = new HBox();
        middle.setPadding(new Insets(5));

        /**
         * Left
         */
        VBox left = new VBox();
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(5));
        left.setAlignment(Pos.CENTER);
        left.setPrefWidth(225);

        HBox leftTop = new HBox();
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label enter = new Label("Enter an Integer:   ");
        tfInteger.requestFocus();
        tfInteger.setPrefWidth(80);
        leftTop.getChildren().addAll(enter, tfInteger);

        left.getChildren().add(leftTop);
        ImageView img = new ImageView(new Image("jdehay_week4/Numbers.jpg"));
        left.getChildren().add(img);

        middle.getChildren().add(left);
        container.getChildren().add(middle);

        /**
         * Right
         */
        GridPane right = new GridPane();
        right.setPadding(new Insets(8));
        right.setVgap(8);

        Label lblFirst = new Label("First Integer:");
        Label lblSecond = new Label("Second Integer:");
        Label lblTenth = new Label("Tenth Integer:");
        Label lblLast = new Label("Last Integer:");
        Label lblFileLength = new Label("File Length:");
        Label lblRandom = new Label("Random Integer: ");

        tfFirst.setEditable(false);
        tfSecond.setEditable(false);
        tfTenth.setEditable(false);
        tfLast.setEditable(false);
        tfFileLength.setEditable(false);
        tfRandom.setEditable(false);

        tfFirst.setPrefWidth(90);
        tfSecond.setPrefWidth(90);
        tfTenth.setPrefWidth(90);
        tfLast.setPrefWidth(90);
        tfFileLength.setPrefWidth(90);
        tfRandom.setPrefWidth(90);

        right.addColumn(0, lblFirst, lblSecond, lblTenth, lblLast, lblFileLength, lblRandom);
        right.addColumn(1, tfFirst, tfSecond, tfTenth, tfLast, tfFileLength, tfRandom);

        middle.getChildren().add(right);

        /**
         * Bottom
         */
        HBox bottom = new HBox();
        bottom.setAlignment(Pos.CENTER);
        bottom.setSpacing(10);
        bottom.setPrefHeight(80);

        Button btnGo = new Button("Go");
        Button btnReset = new Button("Reset");
        Button btnOpen = new Button("Open Files");
        Button btnExit = new Button("Exit");

        btnGo.setOnAction(new goHandler());
        btnReset.setOnAction(new resetHandler());
        btnOpen.setOnAction(new openHandler());
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        bottom.getChildren().addAll(btnGo, btnReset, btnOpen, btnExit);
        container.getChildren().add(bottom);

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Sign Up Today!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }  // End start method

    /**
     * Handles go button
     */
    private static class goHandler implements EventHandler<ActionEvent> {

        public goHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            // must have whole numbers only
            if (!tfInteger.getCharacters().toString().matches("^\\d*$")
                    || tfInteger.getCharacters().toString().isEmpty()) {
                Alert noNumbers = new Alert(Alert.AlertType.WARNING);
                noNumbers.setTitle("Warning");
                noNumbers.setHeaderText("Enter numbers only!");
                noNumbers.showAndWait();
                tfInteger.requestFocus();
                return;
            }
            // entry must be >= 10
            if (Integer.parseInt(tfInteger.getCharacters().toString()) < 10) {
                Alert tooSmall = new Alert(Alert.AlertType.WARNING);
                tooSmall.setTitle("Warning");
                tooSmall.setHeaderText("Minimum entry is 10!");
                tooSmall.showAndWait();
                tfInteger.requestFocus();
                return;
            }
            goButton = new Go_SMH(Integer.parseInt(tfInteger.getCharacters().toString()));
            try {
                tfFileLength.setText(goButton.fileLength());
            } catch (IOException ex) {
                Logger.getLogger(Jdehay_week4_SMH.class.getName()).log(Level.SEVERE, null, ex);
            }
            tfFirst.setText(goButton.firstInt());
            tfSecond.setText(goButton.secondInt());
            tfTenth.setText(goButton.tenthInt());
            tfLast.setText(goButton.lastInt());
            tfRandom.setText(goButton.randomInt() + " @: " + goButton.getPosition());
        }
    }

    /**
     * clear all fields
     */
    private static class resetHandler implements EventHandler<ActionEvent> {

        public resetHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            tfInteger.clear();
            tfFirst.clear();
            tfSecond.clear();
            tfTenth.clear();
            tfLast.clear();
            tfFileLength.clear();
            tfRandom.clear();
            tfInteger.requestFocus();
        }
    }

    private static class openHandler implements EventHandler<ActionEvent> {

        public openHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            if (!tfInteger.getCharacters().toString().matches("^\\d*$")
                    || tfInteger.getCharacters().toString().isEmpty()) {
                Alert noNumbers = new Alert(Alert.AlertType.WARNING);
                noNumbers.setTitle("Warning");
                noNumbers.setHeaderText("Enter an integer before trying to show"
                        + " the files!");
                noNumbers.showAndWait();
                tfInteger.requestFocus();
                return;
            }
            //SMH openButton.transform(goButton.getFile());
            //SMH Call a method to open the files.
            OpenFiles();
        }
    }
    /**SMH
     * OpenFiles
     * This opens text files in Windows. You will need to find an equivalent for
     * Linux. I have commented out the validation checks. You should write those
     * in a validation subclass. I left the code there so you could see it.
     */
    private static void OpenFiles() {
        Runtime rs = Runtime.getRuntime();
        String fileText = "ConvertedText.txt";
        String fileDat = "numbers.dat";
        try {
            //if (val.fileExist(fileText)) {
                rs.exec("notepad " + fileText); //Open text file
//            }
//            if (val.fileExist(fileDat)) {
                rs.exec("notepad " + fileDat); //Open data file
//            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

}  //End Class Jdehay_week4_SMH

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
