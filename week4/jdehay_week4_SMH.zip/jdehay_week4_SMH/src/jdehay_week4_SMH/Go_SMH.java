package jdehay_week4_SMH;
/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week4
  *  @Date: Feb 26, 2018
  *  @Subclass Go Description:
  */

//Imports
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.logging.Level;
import java.util.logging.Logger;

//Begin Subclass Go_SMH
public class Go_SMH {
    
    private int entry;
    private RandomAccessFile file;
    private int position;
    
    public Go_SMH(int userEntry) {
        entry = userEntry;
        
        try {
            this.file = new RandomAccessFile("numbers.dat", "rw");
        } catch (FileNotFoundException e) {
            
        }
    }

    protected String fileLength() throws IOException {
        int test = 0;
        file.setLength(0);
        for (int i = 0; i < entry; i++) {
            test = (int) (Math.random() * 100);
            file.writeInt(test);
        }
        return String.valueOf(file.length());
    }

    protected String firstInt() {
        try {
            file.seek(0);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go_SMH.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    protected String secondInt() {
        try {
            file.seek(1 * 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go_SMH.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    protected String tenthInt() {
        try {
            file.seek(9 * 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go_SMH.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    protected String lastInt() {
        try {
            file.seek(file.length() - 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go_SMH.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    protected String randomInt() {
        position = (int) (Math.random() * entry);
        try {
            file.seek(position * 4);
            return String.valueOf(file.readInt());
        } catch (IOException ex) {
            Logger.getLogger(Go_SMH.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "Failed";
    }

    protected String getPosition() {
        return String.valueOf(position);
    }
    
    protected RandomAccessFile getFile() {
        return file;
    }

} // End Subclass Go_SMH

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/