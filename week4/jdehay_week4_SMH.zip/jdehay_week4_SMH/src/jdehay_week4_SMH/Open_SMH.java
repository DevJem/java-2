package jdehay_week4_SMH;



/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_week4
  *  @Date: Feb 26, 2018
  *  @Subclass Open Description:
  */
//Imports
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.file.Path;
import java.nio.file.Paths;

//Begin Subclass Open_SMH
class Open_SMH {

    void transform(RandomAccessFile file) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter("ConvertedText.txt");
            try (BufferedWriter bw = new BufferedWriter(pw)) {
                for (int i = 0; 8 < file.length() / 4; i++) {
                    file.seek(i * 4);
                    String num = Integer.toString(file.readInt());
                    bw.write("Number at position " + i + ": " + num);
                    bw.newLine();
                }
            }
            pw.close();
        } catch (IOException ex) {
            pw.close();
        }
        openFiles();
    }

    private void openFiles() {
        Runtime rs = Runtime.getRuntime();
        String fileText = "ConvertedText.txt";
        String fileDat = "numbers.dat";
        try {            
            if (val.fileExit(fileText)) {
                
                Process p = rs.exec("/usr/bin/gedit " + fileText);
            }
            if (val.fileExit(fileDat)) {
                Process p = rs.exec("/usr/bin/gedit " + fileDat);
            }
        } catch (IOException ex) {
            
        }
    }

    private static class val {

        // Help from https://stackoverflow.com/a/17677850/4196281
        // Help from https://stackoverflow.com/a/15954821/4196281
        private static boolean fileExit(String fileName) {
            Path p = Paths.get("");
            String pwd = p.toAbsolutePath().toString();
//            System.out.println(pwd);  //for testing
            if (new File(pwd + fileName).exists()) {
                return true;
            }
            return false;
        }
    }

    
} // End Subclass Open_SMH

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/