package jdehay_week14;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week14
 * @Date: Apr 26, 2018
 * @Description: This program implements a GUI that accepts a name and age and
 * applies that information to a hash map. It then allows the user to find
 * and/or remove a saved record based on a key entered.
 * @Note: This program was written on a Linux build
 */
//Imports
import java.util.Set;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

//Begin Class Jdehay_week14
public class Jdehay_week14 extends Application {

    // Global declarations
    private static TextField tfName = new TextField();
    private static TextField tfAge = new TextField();
    private static TextArea taResult = new TextArea();
    private static TextArea taLeft = new TextArea();
    private static Button btnEnter = new Button("Enter");
    private static Button btnFind = new Button("Find");
    private static Button btnRemove = new Button("Remove");
    private static Button btnClear = new Button("Clear");
    private static Button btnExit = new Button("Exit");
    private static MyMap<String, Integer> hash = new MyHashMap<>();

    @Override
    public void start(Stage primaryStage) throws Exception {

        /**
         * Container for app
         */
        HBox container = new HBox(8);
        container.setPrefWidth(575);
        container.setPadding(new Insets(10));

        /**
         * Left
         */
        // container for left side
        VBox left = new VBox(10);
        left.setStyle("-fx-border-color: red;");
        left.setPadding(new Insets(10));
        left.setAlignment(Pos.TOP_CENTER);

        // left top
        HBox leftTop = new HBox(6);
        leftTop.setAlignment(Pos.CENTER_LEFT);
        Label lblName = new Label("Name:");
        Label lblAge = new Label("Age:");
        tfName.setPrefWidth(100);
        tfAge.setPrefWidth(55);
        leftTop.getChildren().addAll(lblName, tfName, lblAge, tfAge);
        left.getChildren().add(leftTop);

        // Left Mid
        int buttonWidth = 80;
        FlowPane leftMid = new FlowPane();
        leftMid.setHgap(6);
        leftMid.setVgap(5);
        leftMid.setAlignment(Pos.CENTER);
        btnEnter.setPrefWidth(buttonWidth);
        btnFind.setPrefWidth(buttonWidth);
        btnRemove.setPrefWidth(buttonWidth);
        btnClear.setPrefWidth(buttonWidth);
        btnExit.setPrefWidth(buttonWidth);
        leftMid.getChildren().addAll(btnEnter, btnFind, btnRemove, btnClear,
                btnExit);
        left.getChildren().add(leftMid);

        // Left bottom
        taLeft.setWrapText(true);
        taLeft.setEditable(false);
        left.getChildren().add(taLeft);

        // Add left to container
        container.getChildren().add(left);

        /**
         * Right
         */
        VBox right = new VBox(10);
        right.setPadding(new Insets(5));
        right.setStyle("-fx-border-color: red;");
        taResult.setPrefHeight(285);
        taResult.setWrapText(true);
        taResult.setEditable(false);
        right.getChildren().add(taResult);
        container.getChildren().add(right);

        // make buttons do stuff
        btnEnter.setOnAction(new EnterHandler());
        btnFind.setOnAction(new FindHandler());
        btnRemove.setOnAction(new RemoveHandler());
        btnClear.setOnAction(new ClearHandler());
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Sign Up Today!");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method

    /**
     * Create custom alerts when necessary
     * @param body 
     */
    private static void MyAlert(String body) {

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText("Error, Error...");
        alert.setContentText(body);
        alert.showAndWait();
    }  // End Alert Method
    
    /**
     * Validate entries in name and age text fields
     */
    private static class ValidateNameAndAge {
        
        public static boolean ValidateName() {
            if (!tfName.getCharacters().toString().matches("^\\D+$")) {
                Jdehay_week14.MyAlert("Please enter a name");
                tfName.clear();
                tfName.requestFocus();
                return true;
            }
            return false;
        }
        
        public static boolean ValidateAge() {
            if (!tfAge.getCharacters().toString().matches("^\\d+$")) {
                Jdehay_week14.MyAlert("Please enter an age.");
                tfAge.clear();
                tfAge.requestFocus();
                return true;
            }
            return false;
        }
    }
    
    /**
     * Clears the Result Text Area, prints the hash contents, clears the
     * text fields, and replaces focus back to tfName
     */
    private static class PrintList {
        public static void print() {
            
            taResult.clear();
            /**
             * Modified from GitHub code by mwhawkins found at 
             * https://github.com/mwhawkins/CustomJavaHashmap/blob/master/Main.java
             */
            if (hash.size() > 0 && !hash.isEmpty()) {
                Set<MyMap.Entry<String, Integer>> set = hash.entrySet();
                for (MyMap.Entry<String, Integer> entry : set) {
                    taResult.appendText(entry.key + " is " + entry.value + " years old.\n");
                }
            }
            tfName.clear();
            tfAge.clear();
            tfName.requestFocus();
        }
    }

    /**
     * Handle enter button to enter name and age into the hash
     */
    private static class EnterHandler implements EventHandler<ActionEvent> {

        public EnterHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            
            if (ValidateNameAndAge.ValidateName() || ValidateNameAndAge.ValidateAge()) 
                return;
            String name = tfName.getCharacters().toString();
            
            // Only create unique keys
            if (hash.containsKey(name)) {
                taLeft.setText(name + " is already in the HashMap.");
                tfName.clear();
                tfAge.clear();
                tfName.requestFocus();
                return;
            }
            Integer age = Integer.parseInt(tfAge.getCharacters().toString());
            hash.put(name, age);
            tfName.clear();
            tfAge.clear();
            
            PrintList.print();
            
            taLeft.setText(name + " was entered into the Hashmap.");
        }
    }

    /**
     * Handles find button to search the hashmap for a key and displays
     * the info in taLeft
     */
    private static class FindHandler implements EventHandler<ActionEvent> {

        public FindHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            if (ValidateNameAndAge.ValidateName()) 
                return;
            String key = tfName.getCharacters().toString();
            
            if (hash.containsKey(key))
                taLeft.setText(key + " is " + hash.get(key).toString() + " years old!");
            else
                taLeft.setText(key + " does not exist in the HashMap!");
        }
    }

    /**
     * Handles the Remove button when an applicable key is entered
     */
    private static class RemoveHandler implements EventHandler<ActionEvent> {

        public RemoveHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            if (ValidateNameAndAge.ValidateName()) 
                return;
            
            String key = tfName.getCharacters().toString();
            if (hash.containsKey(key)) {
                hash.remove(key);
                taLeft.setText(key + " has been removed.");
            }
            else
                taLeft.setText(key + " does not exist in the HashMap!");
            
            PrintList.print();
        }
        
    }

    /**
     * Handles the clear button to clear both text areas, the hashmap, and all
     * other fields.
     */
    private static class ClearHandler implements EventHandler<ActionEvent> {

        public ClearHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            // Dont clear empty hash
            if (hash.isEmpty()) {
                Jdehay_week14.MyAlert("Nothing to clear!");
                taLeft.clear();
                tfName.clear();
                tfAge.clear();
                tfName.requestFocus();
                return;
            }
            taLeft.clear();
            taResult.clear();
            tfName.clear();
            tfAge.clear();
            hash.clear();
            taLeft.setText("The HashMap is now empty.");
            tfName.requestFocus();
        }
    }
}  //End Class Jdehay_week14

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
