package jdehay_week3;

/**
 * @Course: SDEV 350 ~ Java Programming II
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_week3
 * @Date: Feb 10, 2018
 * @Description: This program is an operational gui form that will populate
 *      information, allow the user to verify it, and clear everything when
 *      it's accepted
 * @Note: This program was written on a Linux build
 */
//Imports
import java.util.ArrayList;
import java.util.Optional;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

//Begin Class Jdehay_week3
public class Jdehay_week3 extends Application {

    // Global declarations
    // name boxes
    private static Label lblFname = new Label("First Name:");
    private static TextField tfFname = new TextField();
    private static Label lblLname = new Label("Last Name:");
    private static TextField tfLname = new TextField();
    private static Label lblMI = new Label("MI:");
    private static TextField tfMI = new TextField();

    // address 1
    private static Label lblAdd1 = new Label("Street Address:");
    private static TextField tfAdd1 = new TextField();

    // address 2
    private static Label lblAdd2 = new Label("Address Continued:");
    private static TextField tfAdd2 = new TextField();

    // city state zip
    private static Label lblCity = new Label("City:");
    private static TextField tfCity = new TextField();
    private static Label lblState = new Label("State:");
    private static ComboBox<String> cbState = new ComboBox<>();
    private static Label lblZip = new Label("Zip:");
    private static TextField tfZip = new TextField();

    // phone number
    private static Label lblPhone = new Label("Phone Number:");
    private static TextField tfPhone = new TextField();
    private static CheckBox chkHome = new CheckBox("Home");
    private static CheckBox chkWork = new CheckBox("Work");
    private static CheckBox chkCell = new CheckBox("Cell");
//    /**
//     * radiobutton would make more sense in this context but I included the
//     * code for checkboxes as per the assignment.
//     */
//    ToggleGroup group = new ToggleGroup();
//    RadioButton chkHome = new RadioButton("Home");
//    RadioButton chkWork = new RadioButton("Work");
//    RadioButton chkCell = new RadioButton("Cell");
//    chkHome.setToggleGroup(group);
//    chkWork.setToggleGroup(group);
//    chkCell.setToggleGroup(group);
    
    // email
    private static Label lblPemail = new Label("Email Primary:");
    private static TextField tfPemail = new TextField();
    private static Label lblSemail = new Label("Secondary:");
    private static TextField tfSemail = new TextField();

    private static Stage confirmation = new Stage();            

    
    /**
     * Begin start method
     *
     * @param primaryStage
     * @throws Exception
     */
    @Override
    public void start(Stage primaryStage) throws Exception {

        primaryStage.setResizable(false);

        // contains the whole app
        BorderPane container = new BorderPane();
        container.setPadding(new Insets(20));

        /**
         *
         * build the top
         *
         */
        // top toptext
        Font top = Font.font("Serif", FontPosture.ITALIC, 40);
        Text topText1 = new Text("Welcome to Our Mailing List");
        topText1.setStyle("-fx-stroke: black; -fx-fill: #ab0000;");
        topText1.setFont(top);

        // bottom toptext
        Text topText2 = new Text("Please fill out the information below and "
                + "click the Enter button");
        topText2.setFont(Font.font("Times New Roman", FontWeight.BOLD,
                FontPosture.ITALIC, 20));

        // put top toegether and set it
        VBox topbox = new VBox();
        topbox.setAlignment(Pos.CENTER);
        topbox.getChildren().add(topText1);
        topbox.getChildren().add(topText2);
        container.setTop(topbox);

        /**
         *
         * build the bottom
         *
         */
        // image
        ImageView img = new ImageView(new Image("jdehay_week3/my_image.jpg"));

        // buttons
        VBox buttons = new VBox(7);
        buttons.setPadding(new Insets(10));
        Button btnEnter = new Button("Enter");
        Button btnClear = new Button("Clear");
        Button btnExit = new Button(" Exit ");
        buttons.getChildren().addAll(btnEnter, btnClear, btnExit);

        // button actions
        btnEnter.setOnAction(new enterHandler());
        btnClear.setOnAction(new clearHandler());
        btnExit.setOnAction((ActionEvent e) -> {
            System.exit(0);
        });

        // put bottom together and set it
        HBox bottom = new HBox(25);
        bottom.setPadding(new Insets(10, 20, 20, 0));
        bottom.getChildren().add(buttons);
        bottom.getChildren().add(img);
        container.setBottom(bottom);

        /**
         *
         * build the center
         *
         */
        // grid
        GridPane center = new GridPane();
//        center.setGridLinesVisible(true);  // troubleshooting purposes
        center.setHgap(8);
        center.setVgap(5);
        center.setPadding(new Insets(10, 10, 10, 10));
        center.setStyle("-fx-border-color: red;");

        // Name
        tfMI.setPrefWidth(40);

        GridPane.setConstraints(lblFname, 0, 0, 2, 1);
        GridPane.setConstraints(tfFname, 2, 0);
        GridPane.setConstraints(lblLname, 3, 0);
        GridPane.setConstraints(tfLname, 4, 0, 2, 1);
        GridPane.setConstraints(lblMI, 7, 0);
        GridPane.setConstraints(tfMI, 8, 0);

        // address 1
        GridPane.setConstraints(lblAdd1, 0, 1, 2, 1);
        GridPane.setConstraints(tfAdd1, 2, 1, 7, 1);

        // address 2
        GridPane.setConstraints(lblAdd2, 0, 2, 2, 1);
        GridPane.setConstraints(tfAdd2, 2, 2, 7, 1);

        // retrieved convenient list from https://is.gd/rwSURj
        ObservableList<String> statesList = FXCollections.observableArrayList(
            "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID",
            "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS",
            "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK",
            "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV",
            "WI", "WY"
        );
        // City State and Zip
        cbState.setItems(statesList);
        cbState.setOnKeyPressed((KeyEvent e) -> {  
            cbState.show();        // show list when a key is pressed
        });

        GridPane.setConstraints(lblCity, 0, 3);
        GridPane.setConstraints(tfCity, 1, 3, 2, 1);
        GridPane.setConstraints(lblState, 3, 3);
        GridPane.setConstraints(cbState, 4, 3);
        GridPane.setConstraints(lblZip, 5, 3);
        GridPane.setConstraints(tfZip, 6, 3, 3, 1);

        // tfPhone number chkHome/work/cell
        chkHome.setOnAction(new chkHomeHandler());
        chkWork.setOnAction(new chkWorkHandler());
        chkCell.setOnAction(new chkCellHandler());

        GridPane.setConstraints(lblPhone, 0, 4, 2, 1);
        GridPane.setConstraints(tfPhone, 2, 4);
        GridPane.setConstraints(chkHome, 3, 4);
        GridPane.setConstraints(chkWork, 4, 4);
        GridPane.setConstraints(chkCell, 5, 4);

        // primary and secondary email
        GridPane.setConstraints(lblPemail, 0, 5, 2, 1);
        GridPane.setConstraints(tfPemail, 2, 5);
        GridPane.setConstraints(lblSemail, 3, 5);
        GridPane.setConstraints(tfSemail, 4, 5, 5, 1);

        // put center together and set it
        center.getChildren().addAll(lblFname, tfFname, lblLname, tfLname, lblMI, tfMI,
                lblAdd1, tfAdd1, lblAdd2, tfAdd2,
                lblCity, tfCity, lblState, cbState, lblZip, tfZip,
                lblPhone, tfPhone, chkHome, chkWork, chkCell,
                lblPemail, tfPemail, lblSemail, tfSemail
        );
        center.setAlignment(Pos.CENTER);

        container.setCenter(center);

        /**
         *
         * Place everything together and show it
         *
         */
        Scene scene = new Scene(container);

        primaryStage.setTitle("Sign Up Today!");
        primaryStage.setScene(scene);
        primaryStage.show();

    }  // End start method
    
    public static void clearAll() {
        tfFname.setText("");
        tfLname.setText("");
        tfMI.setText("");
        tfAdd1.setText("");
        tfAdd2.setText("");
        tfCity.setText("");
        tfZip.setText("");
        tfPhone.setText("");
        tfPemail.setText("");
        tfSemail.setText("");
        cbState.setValue(cbState.getItems().get(0));
        chkHome.setSelected(false);
        chkWork.setSelected(false);
        chkCell.setSelected(false);
    }
    
    /**
     * handles enter button action
     */
    private static class enterHandler implements EventHandler<ActionEvent> {

        public enterHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            ArrayList<Label> lblBadList = new ArrayList<>();
            ArrayList<Label> lblGoodList = new ArrayList<>();
            int errorCount = 0;
            String errorMessage = "";
            // Regex for emails from https://stackoverflow.com/a/44674038/4196281
            Pattern patern = Pattern.compile("^([\\w-\\.]+){1,64}@([\\w&&[^_]]+"
                    + "){2,255}\\.[a-z]{2,}$");
            
            // first name
            if (!tfFname.getCharacters().toString().matches("^[\\D]+")) {
                lblBadList.add(lblFname);
                errorCount++;
                errorMessage += "Enter only letters for your First name\n";
            } else {
                lblGoodList.add(lblFname);
            }
            
            // last name
            if (!tfLname.getCharacters().toString().matches("^[\\D]+")) {
                lblBadList.add(lblLname);
                errorCount++;
                errorMessage += "Enter only letters for your Last name\n";
            } else {
                lblGoodList.add(lblLname);
            }
            
            // middle initial
            if (!tfMI.getCharacters().toString().matches("^[\\D]?")) {
                lblBadList.add(lblMI);
                errorCount++;
                errorMessage += "Enter only one letter for your middle initial\n";
            } else {
                lblGoodList.add(lblMI);
            }
            
            // address 1
            if (!tfAdd1.getCharacters().toString().matches("^[0-9]*.*")) {
                lblBadList.add(lblAdd1);
                errorCount++;
                errorMessage += "Address must be in this format: street number street name\n";
            } else {
                lblGoodList.add(lblAdd1);
            }
            
            // address 2
            if (!tfAdd2.getCharacters().toString().matches("^[0-9]*.*")) {
                lblBadList.add(lblAdd2);
            } else {
                lblGoodList.add(lblAdd2);
            }
            
            // city
            if (!tfCity.getCharacters().toString().matches("^[a-zA-Z]*")) {
                lblBadList.add(lblCity);
                errorCount++;
                errorMessage += "Enter only letters for your city\n";
            } else {
                lblGoodList.add(lblCity);
            }
            
            // zip code
            if (!tfZip.getCharacters().toString().matches("^[0-9]{5}|\\d{0}(?:-[0-9]{4})?$")) {
                lblBadList.add(lblZip);
                errorCount++;
                errorMessage += "Zip codes should be in this format: nnnnn or nnnnn-nnnn\n";
            } else {
                lblGoodList.add(lblZip);
            }
            
            // phone number (modified from https://is.gd/EYC0lw)
            if (!tfPhone.getCharacters().toString().matches("(?:\\+?(1)|(1?))?"
                    + "[\\s_.-]?\\(?(\\d{3}|\\d{0})\\)?[\\s_.-]?(\\d{3}|\\d{0}"
                    + ")[\\s_.-]?(\\d{4}|d{0})")) {
                lblBadList.add(lblPhone);
                errorCount++;
                errorMessage += "Phone number should be in this format: nnn "
                        + "nnn nnnn or nnn-nnn-nnnn or nnn.nnn.nnnn\n";
            } else {
                lblGoodList.add(lblPhone);
            }
            
            // Primary email
            if (!patern.matcher(tfPemail.getCharacters()).matches()) {
                lblBadList.add(lblPemail);
                errorCount++;
                errorMessage += "Email should be in this format name@domain.com\n";
            } else {
                lblGoodList.add(lblPemail);
            }
            
            // Secondary email
            if (!patern.matcher(tfSemail.getCharacters()).matches()) {
                lblBadList.add(lblSemail);
                errorCount++;
                errorMessage += "Email should be in this format name@domain.com\n";
            } else {
                lblGoodList.add(lblSemail);
            }
            
            /**
             * These are available to uncomment should the state and phone
             * type become required
             */
//            // State
//            if (cbState.getSelectionModel().getSelectedItem() == null || 
//                    cbState.getSelectionModel().getSelectedItem().matches("")) {
//                lblState.setTextFill(Color.web("#cc0000"));
//                errorCount++;
//                errorMessage += "Select a state from the drop down menu.\n";
//            } else {
//                lblState.setTextFill(Color.web("#000000"));
//            }
//            
//            // Phone type 
//            if (!chkHome.isSelected() && !chkWork.isSelected() && 
//                    !chkCell.isSelected()) {
//                chkHome.setTextFill(Color.web("#cc0000"));
//                chkWork.setTextFill(Color.web("#cc0000"));
//                chkCell.setTextFill(Color.web("#cc0000"));
//                errorCount++;
//                errorMessage += "Please select a phone type.\n";
//            } else {
//                chkHome.setTextFill(Color.web("#000000"));
//                chkWork.setTextFill(Color.web("#000000"));
//                chkCell.setTextFill(Color.web("#000000"));
//            }
            
            lblBadList.stream().forEach((field) -> {
                field.setTextFill(Color.web("#cc0000"));
            });

            lblGoodList.stream().forEach((field) -> {
                field.setTextFill(Color.web("#000000"));
            });
            
            // help from https://stackoverflow.com/a/36938061/4196281
            if (!lblBadList.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
                alert.setHeaderText(errorCount + " Error(s)");
                alert.setContentText(errorMessage);
                alert.showAndWait();
            } else {
                popup();
            }
        }

        /**
         * Method to pop up the confirmation screen
         */
        private void popup() {
            VBox container = new VBox();
            container.setPadding(new Insets(20));
            
            GridPane popup = new GridPane();
            popup.setMinHeight(450);
            popup.setMinWidth(400);
            popup.setHgap(10);
            popup.setVgap(12);
            
            // first name
            Label lblTfFName = new Label(tfFname.getText());
            Label lblLblFname = new Label(lblFname.getText());
            GridPane.setConstraints(lblLblFname, 0, 0);
            GridPane.setConstraints(lblTfFName, 1, 0);
            
            // Last name
            Label lblTfLName = new Label(tfLname.getText());
            Label lblLblLname = new Label(lblLname.getText());
            GridPane.setConstraints(lblLblLname, 0, 1);
            GridPane.setConstraints(lblTfLName, 1, 1);
            
            // middle initial
            Label lblTfMI = new Label(tfMI.getText());
            Label lblLblMI = new Label(lblMI.getText());
            GridPane.setConstraints(lblLblMI, 0, 2);
            GridPane.setConstraints(lblTfMI, 1, 2);
            
            // Address 1
            Label lblTfAdd1 = new Label(tfAdd1.getText());
            Label lblLblAdd1 = new Label(lblAdd1.getText());
            GridPane.setConstraints(lblLblAdd1, 0, 3);
            GridPane.setConstraints(lblTfAdd1, 1, 3);
            
            // address 2
            Label lblTfAdd2 = new Label(tfAdd2.getText());
            Label lblLblAdd2 = new Label(lblAdd2.getText());
            GridPane.setConstraints(lblLblAdd2, 0, 4);
            GridPane.setConstraints(lblTfAdd2, 1, 4);
            
            // city
            Label lblTfCity = new Label(tfCity.getText());
            Label lblLblCity = new Label(lblCity.getText());
            GridPane.setConstraints(lblLblCity, 0, 5);
            GridPane.setConstraints(lblTfCity, 1, 5);
            
            // state
            Label lblCbState = new Label(cbState.getValue());
            Label lblLblState = new Label(lblState.getText());
            GridPane.setConstraints(lblLblState, 0, 6);
            GridPane.setConstraints(lblCbState, 1, 6);
            
            // zip code
            Label lblTfZip = new Label(tfZip.getText());
            Label lblLblZip = new Label(lblZip.getText());
            GridPane.setConstraints(lblLblZip, 0, 7);
            GridPane.setConstraints(lblTfZip, 1, 7);
            
            // phone numbers
            Label lblTfPhone = new Label(tfPhone.getText());
            Label lblPhoneNumbers = new Label("Phone Numbers:");
            Label lblHome = new Label("Home:");
            Label lblWork = new Label("Work:");
            Label lblCell = new Label("Cell:");
            
            GridPane.setConstraints(lblPhoneNumbers, 0, 8);
            GridPane.setConstraints(lblHome, 0, 9);
            GridPane.setConstraints(lblWork, 0, 10);
            GridPane.setConstraints(lblCell, 0, 11);
            
            if (chkHome.isSelected()) {
                GridPane.setConstraints(lblTfPhone, 1, 9);
            } else {
                Label lblNa = new Label("N/A");
                popup.add(lblNa, 1, 9);
            }
            
            if (chkWork.isSelected()) {
                GridPane.setConstraints(lblTfPhone, 1, 10);
            } else {
                Label lblNa = new Label("N/A");
                popup.add(lblNa, 1, 10);
            }
            
            if (chkCell.isSelected()) {
                GridPane.setConstraints(lblTfPhone, 1, 11);
            } else {
                Label lblNa = new Label("N/A");
                popup.add(lblNa, 1, 11);
            }
            
            // emails
            Label lblEmails = new Label("Emails:");
            GridPane.setConstraints(lblEmails, 0, 12);
            
            Label lblTfPemail = new Label(tfPemail.getText());
            Label lblLblPemail = new Label(lblPemail.getText());
            GridPane.setConstraints(lblLblPemail, 0, 13);
            GridPane.setConstraints(lblTfPemail, 1, 13);
            
            Label lblTfSemail = new Label(tfSemail.getText());
            Label lblLblSemail = new Label(lblSemail.getText());
            GridPane.setConstraints(lblLblSemail, 0, 14);
            GridPane.setConstraints(lblTfSemail, 1, 14);            
            
            // add nodes to the gridpane
            popup.getChildren().addAll(
                lblLblFname, lblTfFName, lblLblLname, lblTfLName, lblLblMI, lblTfMI,
                lblLblAdd1, lblTfAdd1, lblLblAdd2, lblTfAdd2,
                lblLblCity, lblTfCity, lblLblState, lblCbState, lblLblZip, lblTfZip,
                lblPhoneNumbers, lblHome, lblWork, lblCell, lblTfPhone,
                lblEmails, lblLblPemail, lblTfPemail, lblLblSemail, lblTfSemail
            );
            
            // verify text
            Font italic = Font.font("Serif", FontPosture.ITALIC, 20);
            Text verify = new Text("Please verify the information above.");
            verify.setStyle("-fx-stroke: black; -fx-fill: #ab0000;");
            verify.setFont(italic);
            
            // buttons
            // help from https://stackoverflow.com/a/25038465/4196281
            HBox buttons = new HBox(15);
            buttons.setPadding(new Insets(15));
            Button btnConfirm = new Button("Confirm");
            Button btnEdit = new Button("Edit");
            btnConfirm.setOnAction(new confirmHandler());
            btnEdit.setOnAction((ActionEvent e) -> {
                Stage stage = (Stage) btnEdit.getScene().getWindow();
                stage.close();
            });
            buttons.getChildren().addAll(btnConfirm, btnEdit);
            buttons.setAlignment(Pos.CENTER);
            
            // set everything up for display
            container.getChildren().add(popup);
            container.getChildren().add(verify);
            container.getChildren().add(buttons);
            container.setAlignment(Pos.CENTER);
            Scene confirm = new Scene(container);
            confirmation.setTitle("Confirm data");
            confirmation.setScene(confirm);
            confirmation.show();
        }
    }  // end enterHandler

    /**
     * handles clear button action and clears fields
     */
    private static class clearHandler implements EventHandler<ActionEvent> {

        public clearHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            Jdehay_week3.clearAll();
        }
    }

    /**
     * The next three classes make the checkboxes operate like a radiobutton
     * group
     */
    private static class chkHomeHandler implements EventHandler<ActionEvent> {

        public chkHomeHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            chkWork.setSelected(false);
            chkCell.setSelected(false);
        }
    }

    private static class chkWorkHandler implements EventHandler<ActionEvent> {

        public chkWorkHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            chkHome.setSelected(false);
            chkCell.setSelected(false);
        }
    }

    private static class chkCellHandler implements EventHandler<ActionEvent> {

        public chkCellHandler() {
        }

        @Override
        public void handle(ActionEvent event) {
            chkHome.setSelected(false);
            chkWork.setSelected(false);
        }
    }

    /**
     * Handles confirm button alert and closing the windows
     */
    private static class confirmHandler implements EventHandler<ActionEvent> {

        public confirmHandler() {
        }

        // closes the verify window via http://code.makery.ch/blog/javafx-dialogs-official/
        @Override
        public void handle(ActionEvent event) {
            Dialog dialog = new Dialog<>();
            ImageView img = new ImageView(new Image("jdehay_week3/becool.jpg"));
            dialog.setGraphic(img);
            dialog.setTitle("Entry Confirmed");
            dialog.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
            dialog.setHeaderText("Thank you for joining!");
            dialog.setContentText("Your information has been entered into our "
                    + "database.\nThank you for your interest in our mailing list!");
            ButtonType okType = new ButtonType("Okay", ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(okType);
            Optional<ButtonType> stop = dialog.showAndWait();
            if (stop.get() == okType) {
                confirmation.close();
                Jdehay_week3.clearAll();
            }
        }
    }
}  //End Class Jdehay_Week3

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
