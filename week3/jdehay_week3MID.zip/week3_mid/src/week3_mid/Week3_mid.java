package week3_mid;

/**
 *  @Course: SDEV 350 ~ Java Programming II
 *  @Author Name: Jeremy DeHay
 *  @Assignment Name: week3_mid
 *  @Date: Feb 6, 2018
 *  @Description: week 3 midweek assignment to write anonymous inner class to
 *          handle an action event
 *  @Note: This program was written on a Linux build
 */

//Imports
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

//Begin Class Week3_mid
public class Week3_mid extends Application {
    CheckBox one = new CheckBox();
    CheckBox two = new CheckBox();
    CheckBox three = new CheckBox();
    CheckBox four = new CheckBox();
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        
        FlowPane container = new FlowPane();
        container.setPrefHeight(100);
        
        one.setSelected(true);
        one.setText("One");
        two.setSelected(true);
        two.setText("Two");
        three.setSelected(true);
        three.setText("Three");
        four.setText("Four");
        
        four.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            one.setSelected(false);
            one.setFont(Font.font("Times New Roman", FontWeight.BOLD, 
                    FontPosture.ITALIC, 18));
            two.setSelected(false);
            two.setFont(Font.font("Times New Roman", FontWeight.BOLD, 
                    FontPosture.ITALIC, 18));
            three.setSelected(false);
            three.setFont(Font.font("Times New Roman", FontWeight.BOLD, 
                    FontPosture.ITALIC, 18));
            }
        });

        
        /**
         * 
         * Place everything together and show it
         * 
         */ 
        container.getChildren().addAll(one, two, three, four);
        Scene scene = new Scene(container);
        
        primaryStage.setTitle("");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }  // End start method
}  //End Class Week3_mid

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */